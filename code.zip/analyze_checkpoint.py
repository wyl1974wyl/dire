#!/usr/bin/env python3
"""
Checkpoint Structure Analyzer for RAE/DiT models
Usage: python analyze_checkpoint.py /path/to/0705000.pt
"""

import torch
import sys
import os
from pathlib import Path
from typing import Dict, Any
import json

def get_tensor_info(tensor: torch.Tensor, max_elements: int = 5) -> Dict[str, Any]:
    info = {
        "shape": list(tensor.shape),
        "dtype": str(tensor.dtype),
        "device": str(tensor.device),
        "requires_grad": tensor.requires_grad,
        "numel": tensor.numel(),
        "mean": tensor.float().mean().item() if tensor.numel() > 0 else 0,
        "std": tensor.float().std().item() if tensor.numel() > 0 else 0,
        "min": tensor.float().min().item() if tensor.numel() > 0 else 0,
        "max": tensor.float().max().item() if tensor.numel() > 0 else 0,
    }

    if tensor.numel() <= max_elements:
        info["value"] = tensor.detach().cpu().tolist()
    
    return info

def analyze_state_dict(state_dict: Dict[str, torch.Tensor], prefix: str = "", max_params: int = 10) -> Dict[str, Any]:

    analysis = {
        "total_parameters": 0,
        "trainable_parameters": 0,
        "layers": {},
        "sample_parameters": []
    }

    for name, param in state_dict.items():
        analysis["total_parameters"] += param.numel()
        if param.requires_grad:
            analysis["trainable_parameters"] += param.numel()

        layer_name = name.split('.')[0] if '.' in name else name
        if layer_name not in analysis["layers"]:
            analysis["layers"][layer_name] = {"count": 0, "params": []}
        
        analysis["layers"][layer_name]["count"] += 1

        if len(analysis["sample_parameters"]) < max_params:
            param_info = get_tensor_info(param)
            param_info["name"] = name
            analysis["sample_parameters"].append(param_info)
    
    return analysis

def recursive_analyze(obj: Any, name: str = "root", depth: int = 0, max_depth: int = 5, max_str_len: int = 200) -> str:

    indent = "  " * depth
    
    if depth > max_depth:
        return f"{indent}{name}: <max depth reached>\n"

    if isinstance(obj, torch.Tensor):
        info = get_tensor_info(obj)
        return f"{indent}{name}: Tensor(shape={info['shape']}, dtype={info['dtype']}, " \
               f"mean={info['mean']:.4f}, std={info['std']:.4f})\n"
    
    elif isinstance(obj, dict):
        result = f"{indent}{name}: dict with {len(obj)} keys\n"
        for key, value in list(obj.items())[:10]:
            result += recursive_analyze(value, f"{key}", depth + 1, max_depth)
        if len(obj) > 10:
            result += f"{indent}  ... and {len(obj) - 10} more keys\n"
        return result
    
    elif isinstance(obj, list):
        result = f"{indent}{name}: list with {len(obj)} items\n"
        for i, item in enumerate(obj[:5]):
            result += recursive_analyze(item, f"[{i}]", depth + 1, max_depth)
        if len(obj) > 5:
            result += f"{indent}  ... and {len(obj) - 5} more items\n"
        return result
    
    elif isinstance(obj, (int, float, str, bool)):
        value_str = str(obj)
        if len(value_str) > max_str_len:
            value_str = value_str[:max_str_len] + "..."
        return f"{indent}{name}: {type(obj).__name__} = {value_str}\n"
    
    elif obj is None:
        return f"{indent}{name}: None\n"
    
    else:
        return f"{indent}{name}: {type(obj).__name__} object\n"

def analyze_checkpoint(checkpoint_path: str, output_file: str = None):

    print(f"🔍 Analyzing checkpoint: {checkpoint_path}")
    print("=" * 80)

    try:
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
        print(f"✅ Successfully loaded checkpoint")
    except Exception as e:
        print(f"❌ Failed to load checkpoint: {e}")
        return

    file_size = Path(checkpoint_path).stat().st_size / (1024**3)  # GB
    print(f"📁 File size: {file_size:.2f} GB")

    print("\n📋 Top-level structure:")
    print("-" * 40)
    print(recursive_analyze(checkpoint, "checkpoint"))

    if isinstance(checkpoint, dict):
        print("\n🔬 Detailed state_dict analysis:")
        print("-" * 40)
        
        if "model" in checkpoint:
            print("🧠 Model state_dict:")
            model_analysis = analyze_state_dict(checkpoint["model"])
            print(f"  Total parameters: {model_analysis['total_parameters']:,}")
            print(f"  Trainable parameters: {model_analysis['trainable_parameters']:,}")
            print(f"  Model size: {model_analysis['total_parameters'] * 4 / (1024**3):.2f} GB (float32)")
            print(f"  Number of layers: {len(model_analysis['layers'])}")
            for layer_name, layer_info in list(model_analysis['layers'].items())[:5]:
                print(f"    {layer_name}: {layer_info['count']} parameters")
            if len(model_analysis['layers']) > 5:
                print(f"    ... and {len(model_analysis['layers']) - 5} more layers")
            
            print("\n  Sample parameters (first 5):")
            for param_info in model_analysis['sample_parameters']:
                print(f"    {param_info['name']}: shape={param_info['shape']}, "
                      f"mean={param_info['mean']:.4f}, std={param_info['std']:.4f}")
        
        if "ema" in checkpoint:
            print("\n📈 EMA state_dict:")
            ema_analysis = analyze_state_dict(checkpoint["ema"])
            print(f"  Total parameters: {ema_analysis['total_parameters']:,}")
            print(f"  Note: EMA contains same structure as model, just smoothed weights")

        optimizer_keys = ["opt", "optimizer"]
        for key in optimizer_keys:
            if key in checkpoint:
                print(f"\n⚙️ Optimizer state ({key}):")
                opt_state = checkpoint[key]
                if isinstance(opt_state, dict) and 'state' in opt_state:
                    print(f"  State dict contains {len(opt_state['state'])} parameter groups")
                    if 'param_groups' in opt_state:
                        for i, group in enumerate(opt_state['param_groups']):
                            print(f"  Param group {i}: lr={group.get('lr', 'N/A')}, "
                                  f"betas={group.get('betas', 'N/A')}")
                break

        if "disc" in checkpoint:
            print("\n🎯 Discriminator state_dict:")
            disc_analysis = analyze_state_dict(checkpoint["disc"])
            print(f"  Total parameters: {disc_analysis['total_parameters']:,}")

        print("\n📊 Training metadata:")
        metadata_keys = ["train_steps", "step", "epoch", "config_path", "training_cfg", "cli_overrides"]
        for key in metadata_keys:
            if key in checkpoint:
                print(f"  {key}: {checkpoint[key]}")

        if output_file:
            print(f"\n💾 Saving detailed report to {output_file}...")
            report = {
                "file_path": checkpoint_path,
                "file_size_gb": file_size,
                "top_level_keys": list(checkpoint.keys()),
                "model_analysis": model_analysis if "model" in checkpoint else None,
                "ema_analysis": ema_analysis if "ema" in checkpoint else None,
                "disc_analysis": disc_analysis if "disc" in checkpoint else None,
                "metadata": {k: checkpoint.get(k) for k in metadata_keys if k in checkpoint}
            }
            with open(output_file, 'w') as f:
                json.dump(report, f, indent=2, default=str)
            print("✅ Report saved!")

    print("\n🎯 Checkpoint type inference:")
    if "disc" in checkpoint:
        print("  🔧 This appears to be a STAGE-1 checkpoint (RAE with discriminator)")
    elif "model" in checkpoint and "ema" in checkpoint:
        print("  🚀 This appears to be a STAGE-2 checkpoint (Diffusion model)")
    else:
        print("  ❓ Unknown checkpoint type")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Analyze PyTorch checkpoint structure")
    parser.add_argument("checkpoint", type=str, help="Path to .pt checkpoint file")
    parser.add_argument("--output", "-o", type=str, help="Save detailed report to JSON file")
    parser.add_argument("--max-depth", "-d", type=int, default=3, help="Max recursion depth")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.checkpoint):
        print(f"❌ File not found: {args.checkpoint}")
        sys.exit(1)
    
    analyze_checkpoint(args.checkpoint, args.output)