#!/usr/bin/env python
"""
DIRE Quick Start Script
Automated setup and execution for DIRE experiments
"""

import os
import sys
import subprocess
import argparse
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Color codes
RED = '\033[0;31m'
GREEN = '\033[0;32m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
NC = '\033[0m'  # No Color


def run_command(cmd, check=True):
    """Run shell command"""
    logger.info(f"Running: {cmd}")
    result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
    
    if result.returncode != 0:
        logger.error(f"Command failed: {result.stderr}")
        if check:
            raise RuntimeError(f"Command failed: {cmd}")
    
    if result.stdout:
        logger.info(result.stdout)
    
    return result


def check_requirements():
    """Check if required packages are installed"""
    required_packages = [
        "torch",
        "torchvision", 
        "transformers",
        "timm",
        "yacs",
        "iopath",
        "PIL",
        "numpy"
    ]
    
    missing = []
    for pkg in required_packages:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)
    
    if missing:
        logger.error(f"Missing packages: {missing}")
        logger.info("Install with: pip install " + " ".join(missing))
        return False
    
    return True


def setup_directories():
    """Create necessary directories"""
    dirs = [
        "./ckpt",
        "./output", 
        "./data",
        "./logs"
    ]
    
    for d in dirs:
        os.makedirs(d, exist_ok=True)
        logger.info(f"Created directory: {d}")


def download_dit_weights(output_dir="./ckpt"):
    """Download DiT pretrained weights"""
    dit_path = os.path.join(output_dir, "block0.pt")
    
    if os.path.exists(dit_path):
        logger.info(f"DiT weights already exist: {dit_path}")
        return dit_path
    
    logger.info("Downloading DiT pretrained weights...")
    
    # Try multiple sources
    sources = [
        # HuggingFace (primary)
        {
            "source": "hf",
            "repo_id": "google/rae-dit-base",
            "filename": "pytorch_model.bin"
        },
        # Alternative repo
        {
            "source": "hf", 
            "repo_id": "your-username/dit-weights",
            "filename": "block0.pt"
        }
    ]
    
    for source in sources:
        try:
            cmd = f"python download_dit.py --source {source['source']}"
            if source['source'] == 'hf':
                cmd += f" --repo-id {source['repo_id']} --filename {source['filename']}"
            cmd += f" --output-dir {output_dir} --output-name block0.pt --verify"
            
            result = run_command(cmd, check=False)
            
            if result.returncode == 0 and os.path.exists(dit_path):
                logger.info(f"✅ Successfully downloaded DiT weights")
                return dit_path
                
        except Exception as e:
            logger.warning(f"Failed to download from {source}: {e}")
            continue
    
    # If all sources fail, provide instructions
    logger.error("Failed to download DiT weights from all sources")
    print(f"\n{YELLOW}Please manually download DiT weights:{NC}")
    print(f"1. Download from HuggingFace: https://huggingface.co/google/rae-dit-base")
    print(f"2. Save to: {dit_path}")
    print(f"3. Or specify path with --dit-path")
    
    return None


def run_test(args):
    """Run DIRE test"""
    # Build command
    # Build command - FIXED: Use opts for non-standard parameters
    cmd = f"python run_dire.py --cfg {args.cfg}"
    
    if args.dit_path:
        cmd += f" --dit-path {args.dit_path}"
    
    if args.gpu is not None:
        cmd += f" --gpu {args.gpu}"
    
    # Use --opts for other parameters - FIXED: Proper list formatting
    opts_parts = []
    if args.dataset:
        opts_parts.append(f"CORRUPTION.DATASET={args.dataset}")
    if args.corruption:
        opts_parts.append(f"CORRUPTION.TYPE=['{args.corruption}']")
    if args.severity:
        opts_parts.append(f"CORRUPTION.SEVERITY=[{args.severity}]")
    if args.batch_size:
        opts_parts.append(f"TEST.BATCH_SIZE={args.batch_size}")
    
    if opts_parts:
        cmd += f" --opts {' '.join(opts_parts)}"
    
    # Run command
    try:
        run_command(cmd)
        logger.info("✅ DIRE test completed successfully")
        return True
    except Exception as e:
        logger.error(f"❌ DIRE test failed: {e}")
        return False


def interactive_setup():
    """Interactive setup"""
    print(f"{BLUE}DIRE Quick Start Setup{NC}")
    print("=" * 50)
    
    # Check requirements
    print(f"\n{YELLOW}1. Checking requirements...{NC}")
    if not check_requirements():
        print(f"{RED}Please install missing packages and try again{NC}")
        return False
    print(f"{GREEN}✅ All requirements satisfied{NC}")
    
    # Setup directories
    print(f"\n{YELLOW}2. Setting up directories...{NC}")
    setup_directories()
    
    # Download DiT weights
    print(f"\n{YELLOW}3. Downloading DiT weights...{NC}")
    dit_path = download_dit_weights()
    
    if not dit_path:
        print(f"\n{RED}Failed to download DiT weights automatically{NC}")
        print(f"Please download manually and specify with --dit-path")
        return False
    
    print(f"{GREEN}✅ DiT weights ready: {dit_path}{NC}")
    
    return True


def main():
    parser = argparse.ArgumentParser(description="DIRE Quick Start")
    parser.add_argument("--setup-only", action="store_true",
                       help="Only run setup, don't execute")
    parser.add_argument("--cfg", type=str, default="cfgs/imagenet_c/dire.yaml",
                       help="Config file")
    parser.add_argument("--dit-path", type=str,
                       help="Path to DiT weights")
    parser.add_argument("--dataset", type=str, choices=["imagenet_c", "cifar10_c", "cifar100_c"],
                       help="Dataset to use")
    parser.add_argument("--corruption", type=str,
                       help="Specific corruption type")
    parser.add_argument("--severity", type=int, choices=[1, 2, 3, 4, 5],
                       help="Corruption severity")
    parser.add_argument("--batch-size", type=int,
                       help="Batch size")
    parser.add_argument("--gpu", type=int, default=0,
                       help="GPU ID")
    parser.add_argument("--no-interactive", action="store_true",
                       help="Skip interactive setup")
    
    args = parser.parse_args()
    
    # Print banner
    print(f"{GREEN}========================================{NC}")
    print(f"{GREEN}     DIRE Quick Start Script{NC}")
    print(f"{GREEN}========================================{NC}")
    print()
    
    # Setup (interactive or not)
    if not args.no_interactive:
        print(f"{BLUE}Starting interactive setup...{NC}")
        if not interactive_setup():
            print(f"\n{RED}Setup failed. Please fix issues and try again.{NC}")
            sys.exit(1)
    else:
        print(f"{BLUE}Running in non-interactive mode...{NC}")
        setup_directories()
        if not check_requirements():
            sys.exit(1)
    
    # Exit if setup-only
    if args.setup_only:
        print(f"\n{GREEN}✅ Setup complete!{NC}")
        return
    
    # Run test
    print(f"\n{BLUE}Running DIRE evaluation...{NC}")
    success = run_test(arg