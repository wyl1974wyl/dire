#!/usr/bin/env python

import os
import logging
from typing import Optional, Tuple, Union

import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
import torchvision.transforms as transforms
from transformers import SiglipProcessor, SiglipModel

from datasets.cls_names import get_class_names
from models.dit_block import create_dit_block_from_pretrained

logger = logging.getLogger(__name__)

class DIREEncoder(nn.Module):

    
    def __init__(
        self,
        siglip_model: nn.Module,
        dit_pretrained_path: str,
        num_dit_blocks: int = 1,
        freeze_siglip: bool = True,
        freeze_dit: bool = False
    ):
        super().__init__()
        self.siglip_model = siglip_model
        self.dit_pretrained_path = dit_pretrained_path
        self.num_dit_blocks = num_dit_blocks
        self.freeze_siglip = freeze_siglip
        self.freeze_dit = freeze_dit

        if hasattr(siglip_model, 'vision_model'):
            self.siglip_vision = siglip_model.vision_model
            logger.info("使用 HuggingFace SigLIP2 vision_model")
        elif hasattr(siglip_model, 'visual'):
            self.siglip_vision = siglip_model.visual
            logger.info("使用 timm SigLIP2 visual encoder")
        else:
            raise ValueError("")

        if freeze_siglip:
            self.siglip_vision.requires_grad_(False)
            logger.info("✅ SigLIP2")

        self.dit_blocks = nn.ModuleList([
            create_dit_block_from_pretrained(dit_pretrained_path, block_idx=0)
        ])

        if freeze_dit:
            self.dit_blocks.requires_grad_(False)
            logger.info("✅")

        self._log_parameter_stats()

        self._setup_manual_preprocess()
    
    def _log_parameter_stats(self):

        dit_params = sum(p.numel() for p in self.dit_blocks.parameters())
        siglip_params = sum(p.numel() for p in self.siglip_vision.parameters())
        total_params = siglip_params + dit_params
        
    
    def _setup_manual_preprocess(self):

        self.image_size = 256
        self.image_mean = [0.5, 0.5, 0.5]
        self.image_std = [0.5, 0.5, 0.5]

        self.manual_preprocess = transforms.Compose([
            transforms.Resize((self.image_size, self.image_size), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.ToTensor(),
            transforms.Normalize(mean=self.image_mean, std=self.image_std)
        ])
        
        logger.info("✅")
    
    def forward(self, pixel_values: torch.Tensor) -> torch.Tensor:

        if pixel_values.dim() != 4:
            raise ValueError(f"[B, C, H, W]{pixel_values.shape}")
        
        with torch.set_grad_enabled(not self.freeze_siglip):
            outputs = self.siglip_vision(pixel_values, output_hidden_states=True)

            if hasattr(outputs, 'last_hidden_state'):
                x = outputs.last_hidden_state
            elif hasattr(outputs, 'hidden_states') and outputs.hidden_states:
                x = outputs.hidden_states[-1]
            else:
                x = outputs[0]

            if x.dim() != 3:
                raise RuntimeError(f"SigLIP[B, N, D]{x.shape}")

        with torch.set_grad_enabled(not self.freeze_dit):
            x = self.dit_blocks[0](x)
        
        return x

class DIRETextEncoder(nn.Module):
    
    def __init__(self, siglip_model: nn.Module, freeze_text: bool = False):
        super().__init__()

        if hasattr(siglip_model, 'text_model'):
            self.text_encoder = siglip_model.text_model
            logger.info("HuggingFace SigLIP2 text_model")
        else:

            logger.warning("...")
            from transformers import SiglipTextModel
            self.text_encoder = SiglipTextModel.from_pretrained("google/siglip2-base-patch16-256")

        if freeze_text:
            self.text_encoder.requires_grad_(False)
            logger.info("✅ SigLIP2")
        
        self.freeze = freeze_text
    
    def forward(self, input_ids: torch.Tensor, attention_mask: Optional[torch.Tensor] = None) -> torch.Tensor:

        if input_ids.dim() != 2:
            raise ValueError(f"[B, seq_len]{input_ids.shape}")
        
        with torch.set_grad_enabled(not self.freeze):
            outputs = self.text_encoder(
                input_ids=input_ids,
                attention_mask=attention_mask
            )

            features = outputs.pooler_output
            if features is None:

                features = outputs.last_hidden_state.mean(dim=1)
            
            return features

class DIREModel(nn.Module):

    def __init__(
        self,
        cfg,
        device: torch.device,
        dit_pretrained_path: Optional[str] = None,
        freeze_siglip_vision: bool = True,
        freeze_siglip_text: bool = False,
        freeze_dit: bool = False
    ):
        super().__init__()
        self.cfg = cfg
        self.device = device

        self._validate_config()
        self.processor, self.siglip_model = self._load_siglip_model()

        self.visual_encoder = DIREEncoder(
            siglip_model=self.siglip_model,
            dit_pretrained_path=dit_pretrained_path or cfg.DIRE.DIT_PRETRAINED_PATH,
            num_dit_blocks=1,
            freeze_siglip=freeze_siglip_vision,
            freeze_dit=freeze_dit
        )

        self.text_encoder = DIRETextEncoder(
            siglip_model=self.siglip_model,
            freeze_text=freeze_siglip_text
        )

        self.class_names = get_class_names(cfg.CORRUPTION.DATASET)
        self.text_features = None
        self._precompute_text_features()

        self.logit_scale = getattr(self.siglip_model, 'logit_scale', 
                                 nn.Parameter(torch.tensor(2.6592)))

        self._log_model_summary()
    
    def _validate_config(self):

        if not hasattr(self.cfg, 'DIRE'):
            raise ValueError("DIRE")
        
        if not hasattr(self.cfg.DIRE, 'DIT_PRETRAINED_PATH'):
            raise ValueError("DIRE.DIT_PRETRAINED_PATH")
        
        dit_path = self.cfg.DIRE.DIT_PRETRAINED_PATH
        if not os.path.exists(dit_path):
            raise FileNotFoundError(f"DiT : {dit_path}")
        
        logger.info("✅")
    
    def _load_siglip_model(self) -> tuple:
        """
        Returns:
            tuple: (processor, model)
        """
        logger.info("...")
        
        hf_endpoint = os.environ.get("HF_ENDPOINT", "https://hf-mirror.com")
        logger.info(f"{hf_endpoint}")
        
        try:

            processor = SiglipProcessor.from_pretrained(
                "google/siglip2-base-patch16-256",
                use_fast=True
            )
            
            model = SiglipModel.from_pretrained(
                "google/siglip2-base-patch16-256"
            ).to(self.device)
            
            logger.info("✅")
            return processor, model
            
        except Exception as e:
            logger.error(f": {e}")
            raise
    
    def _precompute_text_features(self):

        logger.info(f" {len(self.class_names)}...")
        
        prompts = [f"a photo of a {name.replace('_', ' ')}." for name in self.class_names]
        

        batch_size = 100
        text_features_list = []
        
        for i in range(0, len(prompts), batch_size):
            batch_prompts = prompts[i:i + batch_size]

            inputs = self.processor(
                text=batch_prompts,
                return_tensors="pt",
                padding=True,
                truncation=True,
                max_length=32
            ).to(self.device)

            attention_mask = getattr(inputs, 'attention_mask', None)
            
            with torch.no_grad():
                features = self.text_encoder(
                    input_ids=inputs.input_ids,
                    attention_mask=attention_mask  
                )
                features = F.normalize(features, dim=-1)
                text_features_list.append(features)
            
            if i % 500 == 0 and i > 0:
                logger.info(f"   {i}/{len(prompts)}")
        
        self.text_features = torch.cat(text_features_list, dim=0)
        logger.info(f"✅ : {self.text_features.shape}")
    
    def _log_model_summary(self):

        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)

    def encode_image(self, images: torch.Tensor) -> torch.Tensor:

        images = images.to(self.device)
        if images.dtype not in [torch.float16, torch.float32, torch.bfloat16]:

        batch_tensors = []
        for i in range(images.shape[0]):
            img = images[i].cpu()
            
            if img.min() < 0 or img.max() > 1:
                img = (img - img.min()) / (img.max() - img.min() + 1e-8)

            if img.dtype != torch.uint8:
                img = (img * 255).clamp(0, 255).byte()
            
            if img.shape[0] == 3: 
                img = img.permute(1, 2, 0)
            
            pil_img = Image.fromarray(img.numpy())

            tensor = self.visual_encoder.manual_preprocess(pil_img)
            batch_tensors.append(tensor)

        pixel_values = torch.stack(batch_tensors).to(self.device)

        features = self.visual_encoder(pixel_values)

        if features.ndim == 3:
            pooled_features = features[:, 0, :]
        else:
            pooled_features = features
        
        return pooled_features
    
    def forward(self, images: torch.Tensor) -> torch.Tensor:

        img_features = self.encode_image(images)

        img_features = F.normalize(img_features, dim=-1)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * img_features @ self.text_features.T
        
        return logits

def load_dire_model(cfg, device: torch.device, **kwargs) -> DIREModel:

    logger.info("DIRE")
    
    try:
        model = DIREModel(cfg=cfg, device=device, **kwargs)
        return model
        
    except Exception as e:
        logger.error(f"DIRE : {e}")
        import traceback
        traceback.print_exc()
        raise

if __name__ == "__main__":

    import argparse
    
    parser = argparse.ArgumentParser(description="")
    parser.add_argument("--dit-path", type=str, help="DiT ")
    args = parser.parse_args()

    class DummyCfg:
        def __init__(self):
            self.CORRUPTION = type('', (), {'DATASET': 'imagenet_c'})()
            self.DIRE = type('', (), {
                'DIT_PRETRAINED_PATH': args.dit_path or "./block0.pt",
                'FREEZE_SIGLIP_VISION': True,
                'FREEZE_SIGLIP_TEXT': False,
                'FREEZE_DIT': False
            })()
    
    cfg = DummyCfg()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    
    print("DIRE...")
    model = load_dire_model(cfg, device)

    print("\n...")
    dummy_images = torch.randn(2, 3, 256, 256).to(device)
    
    with torch.no_grad():
        logits = model(dummy_images)
