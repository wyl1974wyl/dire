#!/usr/bin/env python

import torch
import torch.nn as nn
import math
from typing import Optional, Tuple
import warnings
import logging
import os
import argparse

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DiTAttention(nn.Module):
    """Multi-head self-attention for DiT"""
    
    def __init__(
        self,
        hidden_size: int = 768,
        num_heads: int = 12,
        use_flash_attn: bool = False
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.scale = math.sqrt(self.head_dim)
        self.use_flash_attn = use_flash_attn and torch.cuda.is_available()

        assert hidden_size % num_heads == 0, f"hidden_size({hidden_size}) % num_heads({num_heads}) != 0"
        
        # QKV projection
        self.qkv = nn.Linear(hidden_size, hidden_size * 3, bias=True)
        
        # Output projection
        self.proj = nn.Linear(hidden_size, hidden_size, bias=True)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, N, D = x.shape

        expected_dim = self.hidden_size
        if D != expected_dim:
            raise RuntimeError(f"{expected_dim}")
        
        # Generate Q, K, V
        qkv = self.qkv(x)
        qkv = qkv.reshape(B, N, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # [3, B, num_heads, N, head_dim]
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        if self.use_flash_attn:
            try:
                from flash_attn import flash_attn_func
                out = flash_attn_func(q, k, v, drop=0.0, causal=False)
            except ImportError:
                logger.warning("FlashAttention ")
                out = self._standard_attention(q, k, v)
        else:
            out = self._standard_attention(q, k, v)
        
        # Reshape and project output
        out = out.transpose(1, 2).reshape(B, N, D)
        out = self.proj(out)
        
        return out
    
    def _standard_attention(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        """Scaled Dot-Product Attention"""
        attn = (q @ k.transpose(-2, -1)) / self.scale
        attn = attn.softmax(dim=-1)
        out = attn @ v
        return out


class GLUMLP(nn.Module):
    
    def __init__(self, in_features: int, hidden_features: int, out_features: int):
        super().__init__()
        self.w12 = nn.Linear(in_features, hidden_features * 2, bias=True)
        self.w3 = nn.Linear(hidden_features, out_features, bias=True)
        self.act = nn.GELU()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x12 = self.w12(x)
        x1, x2 = x12.chunk(2, dim=-1)
        x = self.act(x1) * x2  # GLU
        x = self.w3(x)
        return x


class StandardMLP(nn.Module):

    def __init__(self, in_features: int, hidden_features: int, out_features: int):
        super().__init__()
        self.fc1 = nn.Linear(in_features, hidden_features, bias=True)
        self.fc2 = nn.Linear(hidden_features, out_features, bias=True)
        self.act = nn.GELU()
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x)
        return x


class DropPath(nn.Module):
    """Drop paths (Stochastic Depth)"""
    
    def __init__(self, drop_prob: float = 0.0):
        super().__init__()
        self.drop_prob = drop_prob
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.drop_prob == 0.0 or not self.training:
            return x
        
        keep_prob = 1 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        random_tensor.floor_()  
        output = x.div(keep_prob) * random_tensor
        return output


class DiTBlock(nn.Module):

    def __init__(
        self,
        hidden_size: int = 768,
        num_heads: int = 12,
        mlp_ratio: float = 5.333,
        drop_path: float = 0.0,
        use_flash_attn: bool = False,
        mlp_type: str = "auto"
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.mlp_ratio = mlp_ratio
        self.mlp_type = mlp_type
        
        assert hidden_size % num_heads == 0, "hidden_size must be divisible by num_heads"
        
        self.norm1 = nn.LayerNorm(hidden_size, eps=1e-6, bias=True)
        self.norm2 = nn.LayerNorm(hidden_size, eps=1e-6, bias=True)
        
        self.attn = DiTAttention(
            hidden_size=hidden_size,
            num_heads=num_heads,
            use_flash_attn=use_flash_attn
        )

        self.mlp = None

        self.drop_path = DropPath(drop_path) if drop_path > 0.0 else nn.Identity()
        
        logger.debug(f"DiTBlock : hidden_size={hidden_size}, num_heads={num_heads}, drop_path={drop_path}")
    
    def forward(self, x: torch.Tensor, cond: Optional[torch.Tensor] = None) -> torch.Tensor:

        if self.mlp is None:
            raise RuntimeError("MLP not initialized. Please use create_dit_block_from_pretrained to create block.")
        
        # Self-attention with residual
        x = x + self.drop_path(self.attn(self.norm1(x)))
        
        # MLP with residual
        x = x + self.drop_path(self.mlp(self.norm2(x)))
        
        return x


def detect_checkpoint_format(block_state_dict: dict) -> dict:

    config = {}

    norm1_weight = block_state_dict.get('norm1.weight')
    if norm1_weight is None:
        raise ValueError("norm1.weight")
    
    hidden_size = norm1_weight.shape[0]
    config['hidden_size'] = hidden_size
    
    qkv_weight = block_state_dict.get('attn.qkv.weight')
    if qkv_weight is not None:
        total_qkv_dim = qkv_weight.shape[0]
        if total_qkv_dim % 3 == 0:
            qkv_dim = total_qkv_dim // 3
            if qkv_dim == hidden_size:
                if hidden_size == 768:
                    config['num_heads'] = 12
                elif hidden_size == 1024:
                    config['num_heads'] = 16
                else:
                    config['num_heads'] = 12  
            else:

        else:

    else:
        config['num_heads'] = 12  

    if 'mlp.w12.weight' in block_state_dict:
        config['mlp_type'] = 'glu'
        w12_shape = block_state_dict['mlp.w12.weight'].shape
        hidden_features = w12_shape[0] // 2
        config['mlp_ratio'] = hidden_features / hidden_size
    elif 'mlp.fc1.weight' in block_state_dict:
        config['mlp_type'] = 'standard'
        w1_shape = block_state_dict['mlp.fc1.weight'].shape
        hidden_features = w1_shape[0]
        config['mlp_ratio'] = hidden_features / hidden_size
    else:
        raise ValueError("")

    has_norm1_bias = 'norm1.bias' in block_state_dict
    has_norm2_bias = 'norm2.bias' in block_state_dict
    config['requires_bias_fix'] = not (has_norm1_bias and has_norm2_bias)

    config['ignore_keys'] = []
    for k in block_state_dict.keys():
        if 'adaLN_modulation' in k:
            config['ignore_keys'].append(k)
    
    return config


def create_dit_block_from_pretrained(pretrained_path: str, block_idx: int = 0) -> DiTBlock:

    try:
        checkpoint = torch.load(pretrained_path, map_location='cpu')
    except Exception as e:
        raise RuntimeError(f"{pretrained_path}: {e}")

    if 'model' in checkpoint:
        state_dict = checkpoint['model']
    elif 'state_dict' in checkpoint:
        state_dict = checkpoint['state_dict']
    else:
        state_dict = checkpoint

    block_state_dict = {}
    prefix = f'blocks.{block_idx}.'
    
    for k, v in state_dict.items():
        if k.startswith(prefix):
            block_state_dict[k[len(prefix):]] = v
    
    if not block_state_dict:

        alt_prefixes = [f'encoder.blocks.{block_idx}.', f'dit.blocks.{block_idx}.']
        for alt_prefix in alt_prefixes:
            block_state_dict = {}
            for k, v in state_dict.items():
                if k.startswith(alt_prefix):
                    block_state_dict[k[len(alt_prefix):]] = v
            if block_state_dict:
                break
    
    if not block_state_dict:
        available_blocks = set()
        for k in state_dict.keys():
            if 'blocks.' in k:
                try:
                    block_num = int(k.split('.')[1])
                    available_blocks.add(block_num)
                except:
                    pass
        
        raise ValueError(
        )

    try:
        config = detect_checkpoint_format(block_state_dict)
        logger.info(f": {config}")
    except Exception as e:
        raise RuntimeError(f": {e}")

    dit_block = DiTBlock(
        hidden_size=config['hidden_size'],
        num_heads=config['num_heads'],
        mlp_ratio=config['mlp_ratio'],
        drop_path=0.0,
        mlp_type=config['mlp_type']
    )

    if config['mlp_type'] == 'glu':
        dit_block.mlp = GLUMLP(
            in_features=config['hidden_size'],
            hidden_features=int(config['hidden_size'] * config['mlp_ratio']),
            out_features=config['hidden_size']
        )
    else:
        dit_block.mlp = StandardMLP(
            in_features=config['hidden_size'],
            hidden_features=int(config['hidden_size'] * config['mlp_ratio']),
            out_features=config['hidden_size']
        )

    adapted_state_dict = {}
    for k, v in block_state_dict.items():

        if any(ignore_k in k for ignore_k in config['ignore_keys']):
            logger.debug(f": {k}")
            continue

        if 'norm' in k and k.endswith('.weight'):
            adapted_state_dict[k] = v
            bias_key = k.replace('.weight', '.bias')
            if bias_key not in block_state_dict:
                logger.warning(f"LayerNorm bias: {bias_key}")
                adapted_state_dict[bias_key] = torch.zeros_like(v)
        else:
            adapted_state_dict[k] = v

    try:
        missing_keys, unexpected_keys = dit_block.load_state_dict(adapted_state_dict, strict=False)
        
        if missing_keys:
            logger.warning(f" {missing_keys}")
        if unexpected_keys:
            logger.warning(f"{unexpected_keys}")

        critical_keys = ['norm1.weight', 'attn.qkv.weight', 
                        'mlp.w12.weight' if config['mlp_type'] == 'glu' else 'mlp.fc1.weight']
        for key in critical_keys:
            if key in missing_keys:
                raise RuntimeError(f": {key}")
        
    except Exception as e:
        raise RuntimeError(f": {e}")

    total_params = sum(p.numel() for p in dit_block.parameters())
    loaded_params = sum(p.numel() for p in adapted_state_dict.values())

    
    return dit_block


def test_dit_block():

    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint", type=str, help="Path to DiT checkpoint")
    args = parser.parse_args()
    
    if args.checkpoint and os.path.exists(args.checkpoint):
        print(f"...")
        block = create_dit_block_from_pretrained(args.checkpoint, block_idx=0)

        x = torch.randn(2, 197, 768) 
        with torch.no_grad():
            output = block(x)

            assert x.shape == output.shape

    else:

        block.mlp = GLUMLP(768, int(768 * 5.333), 768)
        x = torch.randn(2, 197, 768)
        with torch.no_grad():
            output = block(x)


    param_count = sum(p.numel() for p in block.parameters())
    print(f": {param_count:,}")
    
    return block


if __name__ == "__main__":
    test_dit_block()