#!/usr/bin/env python

import json
import logging
import torch
import torch.nn as nn
import torchvision.transforms as transforms
from typing import Union

from transformers import AutoTokenizer, AutoModel
from PIL import Image
import torch.nn.functional as F
import numpy as np
from open_clip import create_model_and_transforms, get_tokenizer
from robustbench.model_zoo.architectures.utils_architectures import normalize_model, ImageNormalizer
from robustbench.model_zoo.enums import ThreatModel
from robustbench.utils import load_model
from copy import deepcopy

from models import resnet26
from models.custom_siglip_dire import DIREModel, load_dire_model
from datasets.cls_names import get_class_names
from datasets.imagenet_subsets import IMAGENET_A_MASK, IMAGENET_R_MASK, IMAGENET_V2_MASK, IMAGENET_D109_MASK
from datasets.prompts import *

logging.basicConfig(level=logging.INFO, format='%(message)s')
logger = logging.getLogger(__name__)

class ZeroShotSigLIP_FIXED(nn.Module):

    def __init__(self, cfg, device):
        super().__init__()
        self.cfg = cfg
        self.device = device
        
        model_name = "google/siglip2-base-patch16-256"
        logger.info(f": {model_name}")

        self.model = AutoModel.from_pretrained(
            model_name,
            torch_dtype=torch.float16 if cfg.MIXED_PRECISION else torch.float32,
            trust_remote_code=True
        ).to(device)

        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=True
        )

        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token or "<pad>"
        
        self.logit_scale = self.model.logit_scale

        for param in self.model.parameters():
            param.requires_grad = False
        self.model.eval()

        self.text_features = None
        self._precompute_text_features()
    
    def _tokenize_with_mask(self, texts):
        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=32,
            return_tensors="pt"
        ).to(self.device)

        if "attention_mask" not in encoded:
            pad_id = getattr(self.tokenizer, 'pad_token_id', 0)
            encoded["attention_mask"] = (encoded["input_ids"] != pad_id).long()
        
        return encoded
    
    def _precompute_text_features(self):

        class_names = get_class_names(self.cfg.CORRUPTION.DATASET)
        prompts = [f"a photo of a {name.replace('_', ' ')}." for name in class_names]
        
        text_features_list = []
        
        with torch.no_grad():
            for i in range(0, len(prompts), 100):
                batch_prompts = prompts[i:i + 100]
                
                inputs = self._tokenize_with_mask(batch_prompts)

                outputs = self.model.text_model(**inputs)
                
                if outputs.pooler_output is not None:
                    features = outputs.pooler_output
                else:
                    features = outputs.last_hidden_state[:, 0, :]

                features = F.normalize(features, dim=-1)

                if features.abs().max() < 1e-6:
                    raise RuntimeError("❌ ")
                
                text_features_list.append(features)
        
        self.text_features = torch.cat(text_features_list, dim=0)

        similarity = self.text_features @ self.text_features.T
        eye = torch.eye(len(self.text_features), device=self.device)
        inter_class_sim = (similarity * (1 - eye)).mean().item()
        
        logger.info(f"SigLIP2: {inter_class_sim:.4f}")
        if inter_class_sim > 0.7:
            logger.error(f"❌ ")
        
        logger.info(f"✅: {self.text_features.shape}")
    
    def encode_image(self, images):
        if not isinstance(images[0], Image.Image):
            raise TypeError(f"Expected PIL Images, got {type(images[0])}")
        
        preprocess = transforms.Compose([
            transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        ])
        
        image_tensors = torch.stack([preprocess(img) for img in images]).to(self.device)
        
        with torch.no_grad():
            outputs = self.model.vision_model(pixel_values=image_tensors)

            if outputs.pooler_output is not None:
                features = outputs.pooler_output
            else:
                features = outputs.last_hidden_state[:, 0, :]
        
        return features
    
    def forward(self, x, return_features=False):

        if isinstance(x, torch.Tensor):
            imgs_pil = self._tensor_to_pil(x)
            image_features = self.encode_image(imgs_pil)
        else:
            image_features = self.encode_image(x)
        
        image_features = F.normalize(image_features, dim=-1)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * image_features @ self.text_features.T
        
        if return_features:
            return logits, image_features, self.text_features, image_features, self.text_features
        return logits
    
    def _tensor_to_pil(self, tensor):

        B = tensor.shape[0]
        pil_images = []
        
        for i in range(B):
            img = tensor[i].cpu()
            
            if img.min() < 0 or img.max() > 1:
                img = (img - img.min()) / (img.max() - img.min() + 1e-8)
            
            if img.dtype != torch.uint8:
                img = (img * 255).clamp(0, 255).byte()
            
            if img.shape[0] == 3:
                img = img.permute(1, 2, 0)
            
            pil_images.append(Image.fromarray(img.numpy()))
        
        return pil_images


def get_model(cfg, num_classes: int, device: Union[str, torch.device]):

    if getattr(cfg.MODEL, 'USE_DIRE', False):
        if not hasattr(cfg.DIRE, 'DIT_PRETRAINED_PATH') or not cfg.DIRE.DIT_PRETRAINED_PATH:
            raise ValueError("DIRE requires DIT_PRETRAINED_PATH")
        
        model = load_dire_model(cfg, device, cfg.DIRE.DIT_PRETRAINED_PATH)
        model.eval()

    elif getattr(cfg.MODEL, 'USE_SIGLIP', False):
        logger.info(f"========== Loading SigLIP2 ==========")
        model = ZeroShotSigLIP_FIXED(cfg, device=device)
        return model.to(device), None

    elif cfg.MODEL.USE_CLIP:
        logger.info(f"========== Loading CLIP: {cfg.MODEL.ARCH} ==========")
        base_model, _, preprocess = create_model_and_transforms(
            cfg.MODEL.ARCH,
            pretrained=cfg.MODEL.WEIGHTS,
            device=device,
            precision=cfg.CLIP.PRECISION
        )
        
        normalization = preprocess.transforms[-1]
        preprocess.transforms = preprocess.transforms[:-1]
        
        if cfg.MODEL.ADAPTATION == "tpt":
            base_model = ClipTestTimePromptTuning(
                base_model, normalization,
                cfg.MODEL.ARCH, cfg.CORRUPTION.DATASET,
                n_ctx=cfg.TPT.N_CTX, ctx_init=cfg.TPT.CTX_INIT,
                class_token_pos=cfg.TPT.CLASS_TOKEN_POS
            )
        else:
            base_model = ZeroShotCLIP(cfg, base_model, device, normalize=normalization)
        
        return base_model.to(device), preprocess

    elif cfg.CORRUPTION.DATASET == "domainnet126":
        base_model = ResNetDomainNet126(
            arch=cfg.MODEL.ARCH,
            checkpoint_path=cfg.MODEL.CKPT_PATH,
            num_classes=num_classes
        )
        return base_model.to(device), None
    
    else:

        try:
            weights_enum = torchvision.models.get_model_weights(cfg.MODEL.ARCH)
            weights = getattr(weights_enum, cfg.MODEL.WEIGHTS)
            base_model = torchvision.models.get_model(cfg.MODEL.ARCH, weights=weights)
            preprocess = weights.transforms()
            return base_model.to(device), preprocess
        except:

            import timm
            base_model = timm.create_model(cfg.MODEL.ARCH, pretrained=True)
            data_config = timm.data.resolve_model_data_config(base_model)
            preprocess = timm.data.create_transform(**data_config)
            return base_model.to(device), preprocess


def split_up_model(model, arch_name: str, dataset_name: str):

    if hasattr(model, "model") and hasattr(model.model, "pretrained_cfg") and hasattr(model.model, model.model.pretrained_cfg["classifier"]):
        classifier = deepcopy(getattr(model.model, model.model.pretrained_cfg["classifier"]))
        encoder = model
        encoder.model.reset_classifier(0)
        if isinstance(model, ImageNetXWrapper):
            encoder = nn.Sequential(encoder.normalize, encoder.model)

    elif arch_name == "Standard" and dataset_name in {"cifar10", "cifar10_c"}:
        encoder = nn.Sequential(*list(model.children())[:-1], nn.AvgPool2d(kernel_size=8, stride=8), nn.Flatten())
        classifier = model.fc
    elif arch_name == "Hendrycks2020AugMix_WRN":
        normalization = ImageNormalizer(mean=model.mu, std=model.sigma)
        encoder = nn.Sequential(normalization, *list(model.children())[:-1], nn.AvgPool2d(kernel_size=8, stride=8), nn.Flatten())
        classifier = model.fc
    elif arch_name == "Hendrycks2020AugMix_ResNeXt":
        normalization = ImageNormalizer(mean=model.mu, std=model.sigma)
        encoder = nn.Sequential(normalization, *list(model.children())[:2], nn.ReLU(), *list(model.children())[2:-1], nn.Flatten())
        classifier = model.classifier
    elif dataset_name == "domainnet126":
        encoder = model.encoder
        classifier = model.fc
    elif "resnet" in arch_name or "resnext" in arch_name or "wide_resnet" in arch_name or arch_name in {"Standard_R50", "Hendrycks2020AugMix", "Hendrycks2020Many", "Geirhos2018_SIN"}:
        encoder = nn.Sequential(model.normalize, *list(model.model.children())[:-1], nn.Flatten())
        classifier = model.model.fc
    elif "densenet" in arch_name:
        encoder = nn.Sequential(model.normalize, model.model.features, nn.ReLU(), nn.AdaptiveAvgPool2d((1, 1)), nn.Flatten())
        classifier = model.model.classifier
    elif "efficientnet" in arch_name:
        encoder = nn.Sequential(model.normalize, model.model.features, model.model.avgpool, nn.Flatten())
        classifier = model.model.classifier
    elif "mnasnet" in arch_name:
        encoder = nn.Sequential(model.normalize, model.model.layers, nn.AdaptiveAvgPool2d(output_size=(1, 1)), nn.Flatten())
        classifier = model.model.classifier
    elif "shufflenet" in arch_name:
        encoder = nn.Sequential(model.normalize, *list(model.model.children())[:-1], nn.AdaptiveAvgPool2d(output_size=(1, 1)), nn.Flatten())
        classifier = model.model.fc
    elif "vit_" in arch_name and not "maxvit_" in arch_name:
        encoder = TransformerWrapper(model)
        classifier = model.model.heads.head
    elif "swin_" in arch_name:
        encoder = nn.Sequential(model.normalize, model.model.features, model.model.norm, model.model.permute, model.model.avgpool, model.model.flatten)
        classifier = model.model.head
    elif "convnext" in arch_name:
        encoder = nn.Sequential(model.normalize, model.model.features, model.model.avgpool)
        classifier = model.model.classifier
    elif arch_name == "mobilenet_v2":
        encoder = nn.Sequential(model.normalize, model.model.features, nn.AdaptiveAvgPool2d((1, 1)), nn.Flatten())
        classifier = model.model.classifier
    else:
        raise ValueError(f"The model architecture '{arch_name}' is not supported for dataset '{dataset_name}'.")

    if dataset_name in ["imagenet_a", "imagenet_r", "imagenet_v2", "imagenet_d109"]:
        mask = eval(f"{dataset_name.upper()}_MASK")
        classifier = nn.Sequential(classifier, ImageNetXMaskingLayer(mask))

    return encoder, classifier