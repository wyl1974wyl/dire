#!/usr/bin/env python

import torch
import torch.nn as nn
import logging
import torch.nn.functional as F
from transformers import SiglipModel, SiglipTokenizer
from datasets.cls_names import get_class_names

logger = logging.getLogger(__name__)


class ZeroShotSigLIP(nn.Module):

    
    def __init__(self, cfg, device, normalize):
        super().__init__()
        self.cfg = cfg
        self.device = device
        self.normalize = normalize
        

        model_name = "google/siglip2-base-patch16-256"

        self.model = SiglipModel.from_pretrained(
            model_name,
            torch_dtype=torch.float16 if cfg.MIXED_PRECISION else torch.float32,
            local_files_only=False
        ).to(device)
        
        self.tokenizer = SiglipTokenizer.from_pretrained(
            model_name,
            local_files_only=False
        )
        
        self.logit_scale = self.model.logit_scale
        

        self.text_features = None
        self._precompute_text_features()
    
    def _tokenize_with_mask(self, texts):

        encoded = self.tokenizer(
            texts,
            padding=True,
            truncation=True,
            max_length=32,
            return_tensors="pt"
        ).to(self.device)

        if "attention_mask" not in encoded:
            pad_id = self.tokenizer.pad_token_id
            if pad_id is None:
                pad_id = 0
            encoded["attention_mask"] = (encoded["input_ids"] != pad_id).long()
        
        return encoded
    
    def _precompute_text_features(self):

        class_names = get_class_names(self.cfg.CORRUPTION.DATASET)
        prompts = [f"a photo of a {name.replace('_', ' ')}." for name in class_names]
        
        batch_size = 100
        text_features_list = []
        
        with torch.no_grad():
            for i in range(0, len(prompts), batch_size):
                batch_prompts = prompts[i:i + batch_size]

                inputs = self._tokenize_with_mask(batch_prompts)
                
                if i == 0:
                    logger.info(f"【ZeroShot】Input IDs: {inputs['input_ids'][0, :10]}")
                    logger.info(f"【ZeroShot】Attention Mask: {inputs['attention_mask'][0, :10]}")
                    logger.info(f"【ZeroShot】Mask sum: {inputs['attention_mask'][0].sum().item()}")
                
                outputs = self.model.text_model(**inputs)
                features = outputs.pooler_output
                if features is None:
                    features = outputs.last_hidden_state.mean(dim=1)
                
                features = F.normalize(features, dim=-1)

                if i == 0:
                    self._first_batch_features = features.clone()
                else:
                    diff = (features - self._first_batch_features).abs().mean().item()
                    if diff < 1e-4:
                        raise RuntimeError(f"❌: {diff:.8f}")
                
                if features.abs().max() < 1e-6:
                    raise RuntimeError(f"❌")
                
                text_features_list.append(features)
        
        self.text_features = torch.cat(text_features_list, dim=0)

        similarity = self.text_features @ self.text_features.T
        eye = torch.eye(len(self.text_features), device=self.device)
        inter_class_sim = (similarity * (1 - eye)).mean().item()
        
        logger.info(f"ZeroShot: {inter_class_sim:.4f}")
        if inter_class_sim > 0.5:
            logger.error(f"❌")
            
        logger.info(f"✅ : {self.text_features.shape}")
    
    def encode_image(self, images):

        if not isinstance(images[0], Image.Image):
            raise TypeError(f"Expected PIL Images, got {type(images[0])}")
        

        from torchvision import transforms
        preprocess = transforms.Compose([
            transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
        ])
        
        image_tensors = torch.stack([preprocess(img) for img in images]).to(self.device)
        
        with torch.no_grad():
            outputs = self.model.vision_model(pixel_values=image_tensors)
            features = outputs.pooler_output
            if features is None:
                features = outputs.last_hidden_state[:, 0, :]  # CLS token
        
        return features
    
    def forward(self, imgs_test, return_features=False):

        if isinstance(imgs_test, torch.Tensor):
            imgs_pil = self._tensor_to_pil(imgs_test)
            image_features = self.encode_image(imgs_pil)
        else:
            image_features = self.encode_image(imgs_test)
        
        image_features = F.normalize(image_features, dim=-1)

        logit_scale = self.logit_scale.exp()
        logits = logit_scale * image_features @ self.text_features.T
        
        if return_features:
            return logits, image_features, self.text_features, image_features, self.text_features
        return logits
    
    def _tensor_to_pil(self, tensor):

        B = tensor.shape[0]
        pil_images = []
        
        for i in range(B):
            img = tensor[i].cpu()
            
            if img.min() < 0 or img.max() > 1:
                img = (img - img.min()) / (img.max() - img.min() + 1e-8)
            
            if img.dtype != torch.uint8:
                img = (img * 255).clamp(0, 255).byte()
            
            if img.shape[0] == 3:
                img = img.permute(1, 2, 0)
            
            pil_images.append(Image.fromarray(img.numpy()))
        
        return pil_images


class SigLIPTestTimePromptTuning(nn.Module):

    def __init__(self, siglip_model, normalization, arch_name, dataset_name, **kwargs):
        super().__init__()
        self.model = siglip_model
        self.normalize = normalization
        
        logger.warning("SigLIP2 TPT not implemented, using base model")
    
    @property
    def dtype(self):
        return self.model.dtype

    def reset(self):
        logger.info("Reset called (no-op)")

    def forward(self, image):
        return self.model(image)