import os
import torch
import logging
import numpy as np
import methods

from models.model import get_model
from utils.misc import print_memory_info
from utils.eval_utils import get_accuracy, eval_domain_dict
from utils.registry import ADAPTATION_REGISTRY
from datasets.data_loading import get_test_loader
from conf import cfg, load_cfg_from_args, get_num_classes, ckpt_path_to_domain_seq

logger = logging.getLogger(__name__)


def evaluate(description, external_cfg=None):

    if external_cfg is None:
        load_cfg_from_args(description)
    else:
        global cfg
        cfg = external_cfg
        import random
        import numpy as np
        if cfg.RNG_SEED:
            torch.manual_seed(cfg.RNG_SEED)
            torch.cuda.manual_seed(cfg.RNG_SEED)
            np.random.seed(cfg.RNG_SEED)
            random.seed(cfg.RNG_SEED)
            torch.backends.cudnn.benchmark = cfg.CUDNN.BENCHMARK
            if cfg.DETERMINISM:
                torch.backends.cudnn.deterministic = True

    model_type = "SigLIP2" if cfg.MODEL.USE_SIGLIP else "CLIP" if cfg.MODEL.USE_CLIP else "DIRE" if cfg.MODEL.USE_DIRE else "Standard"
    logger.info(f"========== Running BATCLIP with {model_type} Model ==========")
    logger.info(f"Model Architecture: {cfg.MODEL.ARCH}")
    logger.info(f"Adaptation Method: {cfg.MODEL.ADAPTATION}")
    logger.info(f"Dataset: {cfg.CORRUPTION.DATASET}")

    if model_type == "DIRE":
        is_text_frozen = cfg.DIRE.FREEZE_SIGLIP_TEXT
    elif model_type == "SigLIP2":
        is_text_frozen = cfg.SIGLIP.FREEZE_TEXT_ENCODER
    else:
        is_text_frozen = getattr(cfg, model_type.upper()).FREEZE_TEXT_ENCODER
        
    logger.info(f"Bimodal Adaptation: {'Disabled' if is_text_frozen else 'Enabled'}")

    valid_settings = ["reset_each_shift", "continual", "gradual", "mixed_domains", 
                      "correlated", "mixed_domains_correlated", "gradual_correlated", "reset_each_shift_correlated"]
    assert cfg.SETTING in valid_settings, f"The setting '{cfg.SETTING}' is not supported! Choose from: {valid_settings}"

    device = "cuda" if torch.cuda.is_available() else "cpu"
    num_classes = get_num_classes(dataset_name=cfg.CORRUPTION.DATASET)

    base_model, model_preprocess = get_model(cfg, num_classes, device)
    base_model.model_preprocess = model_preprocess

    available_adaptations = ADAPTATION_REGISTRY.registered_names()
    assert cfg.MODEL.ADAPTATION in available_adaptations, \
        f"The adaptation '{cfg.MODEL.ADAPTATION}' is not supported! Choose from: {available_adaptations}"
    model = ADAPTATION_REGISTRY.get(cfg.MODEL.ADAPTATION)(cfg=cfg, model=base_model, num_classes=num_classes)
    logger.info(f"Successfully prepared test-time adaptation method: {cfg.MODEL.ADAPTATION}")

    if cfg.CORRUPTION.DATASET == "domainnet126":
        domain_sequence = ckpt_path_to_domain_seq(ckpt_path=cfg.MODEL.CKPT_PATH)
    elif cfg.CORRUPTION.DATASET in ["imagenet_d", "imagenet_d109"] and not cfg.CORRUPTION.TYPE[0]:
        domain_sequence = ["clipart", "infograph", "painting", "real", "sketch"]
    else:
        domain_sequence = cfg.CORRUPTION.TYPE
    logger.info(f"Using {cfg.CORRUPTION.DATASET} with the following domain sequence: {domain_sequence}")

    domain_seq_loop = ["mixed"] if "mixed_domains" in cfg.SETTING else domain_sequence

    if "gradual" in cfg.SETTING and cfg.CORRUPTION.DATASET in ["cifar10_c", "cifar100_c", "imagenet_c"] and len(cfg.CORRUPTION.SEVERITY) == 1:
        severities = [1, 2, 3, 4, 5, 4, 3, 2, 1]
        logger.info(f"Using the following severity sequence for each domain: {severities}")
    else:
        severities = cfg.CORRUPTION.SEVERITY

    errs = []
    errs_5 = []
    domain_dict = {}

    for i_dom, domain_name in enumerate(domain_seq_loop):
        if i_dom == 0 or "reset_each_shift" in cfg.SETTING:
            try:
                model.reset()
                logger.info("resetting model")
            except AttributeError:
                logger.warning("not resetting model")
        else:
            logger.warning("not resetting model")

        for severity in severities:
            test_data_loader = get_test_loader(
                setting=cfg.SETTING,
                adaptation=cfg.MODEL.ADAPTATION,
                dataset_name=cfg.CORRUPTION.DATASET,
                preprocess=model_preprocess,
                data_root_dir=cfg.DATA_DIR,
                domain_name=domain_name,
                domain_names_all=domain_sequence,
                severity=severity,
                num_examples=cfg.CORRUPTION.NUM_EX,
                rng_seed=cfg.RNG_SEED,
                use_clip=cfg.MODEL.USE_CLIP,
                use_siglip=cfg.MODEL.USE_SIGLIP,
                n_views=cfg.TEST.N_AUGMENTATIONS,
                delta_dirichlet=cfg.TEST.DELTA_DIRICHLET,
                batch_size=cfg.TEST.BATCH_SIZE,
                shuffle=False,
                workers=min(cfg.TEST.NUM_WORKERS, os.cpu_count())
            )

            if i_dom == 0:
                logger.info(f"Using the following data transformation:\n{test_data_loader.dataset.transform}")

            acc, domain_dict, num_samples = get_accuracy(
                model,
                data_loader=test_data_loader,
                dataset_name=cfg.CORRUPTION.DATASET,
                domain_name=domain_name,
                setting=cfg.SETTING,
                domain_dict=domain_dict,
                print_every=cfg.PRINT_EVERY,
                device=device
            )

            err = 1. - acc
            errs.append(err)
            if severity == 5 and domain_name != "none":
                errs_5.append(err)

            logger.info(f"{cfg.CORRUPTION.DATASET} error % [{domain_name}{severity}][#samples={num_samples}]: {err:.2%}")

    if len(errs_5) > 0:
        logger.info(f"mean error: {np.mean(errs):.2%}, mean error at 5: {np.mean(errs_5):.2%}")
    else:
        logger.info(f"mean error: {np.mean(errs):.2%}")

    if "mixed_domains" in cfg.SETTING and len(domain_dict.values()) > 0:
        eval_domain_dict(domain_dict, domain_seq=domain_sequence)

    if cfg.TEST.DEBUG:
        print_memory_info()


if __name__ == '__main__':
    evaluate('"Evaluation.')