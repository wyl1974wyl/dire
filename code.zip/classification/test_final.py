import os
import sys
import subprocess
import argparse
import importlib
import torch
from pathlib import Path

class Colors:
    GREEN = '\033[0;32m'
    RED = '\033[0;31m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    NC = '\033[0m'


def print_section(title):

    print(f"\n{Colors.BLUE}{'='*60}")
    print(f"{title}")
    print(f"{'='*60}{Colors.NC}\n")


def run_test(name, func, critical=True):

    try:
        print(f"{name}...", end=" ")
        result = func()
        if result:
            print(f"{Colors.GREEN}✅{Colors.NC}")
            return True
        else:
            print(f"{Colors.RED}❌{Colors.NC}")
            return False
    except Exception as e:
        print(f"{Colors.RED}❌{e}{Colors.NC}")
        if critical:
            import traceback
            traceback.print_exc()
        return False

def check_imports():
    required = [
        ("torch", "PyTorch"),
        ("transformers", "Transformers"),
        ("timm", "Timm"),
        ("yacs", "YACS"),
        ("PIL", "Pillow"),
        ("numpy", "NumPy"),
        ("iopath", "IOPath")
    ]
    
    missing = []
    for module, name in required:
        try:
            __import__(module)
        except ImportError:
            missing.append(name)
    
    if missing:
        print(f"{Colors.RED}empty: {', '.join(missing)}{Colors.NC}")
        print("please: pip install " + " ".join([m.lower() for m in missing]))
        return False
    
    try:
        import flash_attn
        print(f"{Colors.GREEN}✓ FlashAttention {Colors.NC}")
    except:
        print(f"{Colors.YELLOW}⚠ FlashAttention {Colors.NC}")
    
    return True


def check_checkpoint(dit_path):

    if not os.path.exists(dit_path):
        print(f"{Colors.RED}✗{dit_path}{Colors.NC}")
        return False
    
    try:
        ckpt = torch.load(dit_path, map_location='cpu')
        state_dict = ckpt.get('model', ckpt.get('state_dict', ckpt))

        block0_keys = [k for k in state_dict.keys() if k.startswith('blocks.0.')]
        if not block0_keys:
            print(f"{Colors.RED}✗ blocks.0.* {Colors.NC}")
            return False
        
        print(f"{Colors.GREEN}✓ {len(block0_keys)} {Colors.NC}")
        return True
        
    except Exception as e:
        print(f"{Colors.RED}✗ : {e}{Colors.NC}")
        return False


def check_model_loading(cfg_path, dit_path):
    try:
        sys.path.insert(0, ".")
        from conf import cfg, merge_from_file, assert_and_infer_cfg

        cfg.MODEL.USE_DIRE = True
        cfg.MODEL.ARCH = "siglip2-base-patch16-256"
        cfg.MODEL.ADAPTATION = "dire"
        cfg.DIRE.DIT_PRETRAINED_PATH = dit_path
        cfg.DIRE.NUM_DIT_BLOCKS = 1
        
        if not hasattr(cfg, 'CORRUPTION'):
            cfg.CORRUPTION = type(cfg)()
        cfg.CORRUPTION.DATASET = "imagenet_c"

        assert_and_infer_cfg()

        from models.custom_siglip_dire import load_dire_model
        model = load_dire_model(cfg, torch.device("cpu"))

        dummy_images = torch.randn(1, 3, 256, 256)
        with torch.no_grad():
            logits = model(dummy_images)
        
        if logits is not None and logits.shape[-1] == 1000:
            print(f"{Colors.GREEN}✓ {Colors.NC}")
            print(f"  : {logits.shape}")
            return True
        else:
            expected = "torch.Size([1, 1000])"
            actual = str(logits.shape) if logits is not None else "None"
            print(f"{Colors.RED}✗ {Colors.NC}")
            print(f"  : {expected}")
            print(f"  : {actual}")
            return False
            
    except Exception as e:
        print(f"{Colors.RED}✗ : {e}{Colors.NC}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    main()