"""
DIRE (Diffusion-Informed Representation Enhancement) Test-Time Adaptation Method
Implements confidence-aware adaptation with entropy minimization and distance-compensated loss
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from copy import deepcopy
from methods.base import TTAMethod, forward_decorator
from utils.registry import ADAPTATION_REGISTRY
import logging

# ==================== 新增：预处理相关导入 ====================
from PIL import Image
from torchvision import transforms

logger = logging.getLogger(__name__)

@ADAPTATION_REGISTRY.register()
class DIRE(TTAMethod):
    """
    DIRE Test-Time Adaptation
    
    Key features:
    - Confidence-aware adaptation strategy
    - Entropy minimization for high-confidence samples
    - Distance-compensated loss for low-confidence samples
    - Only adapts LayerNorm parameters in DiT blocks
    """
    
    def __init__(self, cfg, model, num_classes):
        super().__init__(cfg, model, num_classes)
        
        # DIRE-specific parameters
        self.confidence_threshold = cfg.DIRE.CONFIDENCE_THRESHOLD  # τ = 0.8 in paper
        self.distance_compensation_weight = cfg.DIRE.LAMBDA_DC  # λ = 0.5 in paper
        self.entropy_weight = cfg.DIRE.LAMBDA_ENT  # Weight for entropy loss
        
        # Store frozen SigLIP2 encoder for distance computation
        self.frozen_encoder = None
        self._setup_frozen_encoder()
        
        # Loss tracking
        self.losses = {
            'total': [],
            'entropy': [],
            'distance': []
        }
    
    def _setup_frozen_encoder(self):
        """Setup frozen copy of SigLIP2 encoder for distance computation"""
        # Create a copy of the visual encoder without DiT blocks
        if hasattr(self.model, 'visual_encoder') and hasattr(self.model.visual_encoder, 'siglip_vision'):
            # Extract SigLIP2 part from DIRE encoder
            self.frozen_encoder = deepcopy(self.model.visual_encoder.siglip_vision)
            self.frozen_encoder.requires_grad_(False)
            self.frozen_encoder.eval()
            logger.info("✅ 冻结编码器设置成功")
        else:
            logger.warning("⚠️  无法设置冻结编码器，将使用备用方案")
            self.frozen_encoder = None
    
    # ==================== 新增：预处理辅助方法 ====================
    def _preprocess_for_frozen_encoder(self, imgs_tensor):
        """
        为冻结的 SigLIP2 编码器预处理图像（强制 256×256）
        
        Args:
            imgs_tensor: [B, C, H, W] 输入图像张量
            
        Returns:
            torch.Tensor: [B, C, 256, 256] 预处理后的张量
        """
        batch_tensors = []
        
        # 获取 DIREModel 中的预处理管道
        if hasattr(self.model, 'visual_encoder') and hasattr(self.model.visual_encoder, 'manual_preprocess'):
            manual_preprocess = self.model.visual_encoder.manual_preprocess
            logger.debug("使用 DIREModel 中的手动预处理")
        else:
            # 后备方案：使用默认的 SigLIP2 预处理
            logger.warning("使用后备预处理方案")
            manual_preprocess = transforms.Compose([
                transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ])
        
        for i in range(imgs_tensor.shape[0]):
            img = imgs_tensor[i].cpu()
            
            # 确保图像在 [0, 1] 范围内
            if img.min() < 0 or img.max() > 1:
                img = (img - img.min()) / (img.max() - img.min() + 1e-8)
            
            # 转换为 uint8 以创建 PIL 图像
            if img.dtype != torch.uint8:
                img = (img * 255).clamp(0, 255).byte()
            
            # 转换为 HWC 格式
            if img.shape[0] == 3:  # CHW -> HWC
                img = img.permute(1, 2, 0)
            
            # 创建 PIL 图像并应用预处理
            pil_img = Image.fromarray(img.numpy())
            tensor = manual_preprocess(pil_img)
            batch_tensors.append(tensor)
        
        # 堆叠批次并移动到原始设备
        return torch.stack(batch_tensors).to(imgs_tensor.device)
    
    def compute_confidence(self, logits: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """
        Compute prediction confidence and separate high/low confidence samples
        
        Args:
            logits: Model predictions [B, C]
            
        Returns:
            high_conf_mask: Boolean mask for high-confidence samples
            low_conf_mask: Boolean mask for low-confidence samples
            predictions: Predicted class indices
            confidences: Max probability values
        """
        # Compute softmax probabilities
        probs = F.softmax(logits, dim=-1)
        
        # Max probability as confidence measure
        max_probs, predictions = probs.max(dim=-1)
        
        # Separate based on threshold
        high_conf_mask = max_probs >= self.confidence_threshold
        low_conf_mask = max_probs < self.confidence_threshold
        
        return high_conf_mask, low_conf_mask, predictions, max_probs
    
    def entropy_loss(self, logits: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
        """
        Entropy minimization loss for high-confidence samples
        
        Args:
            logits: Model predictions [B, C]
            mask: Boolean mask for samples to include
            
        Returns:
            Mean entropy loss
        """
        if not mask.any():
            return torch.tensor(0.0, device=logits.device, requires_grad=True)
        
        # Compute probabilities
        probs = F.softmax(logits[mask], dim=-1)
        
        # Compute entropy
        entropy = -(probs * torch.log(probs + 1e-8)).sum(dim=-1)
        
        # Return mean entropy (we want to minimize this)
        return entropy.mean()
    
    def distance_compensated_loss(
        self,
        adapted_features: torch.Tensor,
        original_features: torch.Tensor,
        logits: torch.Tensor,
        mask: torch.Tensor
    ) -> torch.Tensor:
        """
        Distance-compensated loss for low-confidence samples
        
        L_dc = log E[i,j] [exp(||v_i - v_j||^2 / (τ * d_avg))] - 1
        
        Args:
            adapted_features: Features from adapted model [B, D]
            original_features: Features from frozen SigLIP2 [B, D]
            logits: Model predictions [B, C]
            mask: Boolean mask for low-confidence samples
            
        Returns:
            Distance-compensated loss
        """
        if not mask.any():
            return torch.tensor(0.0, device=logits.device, requires_grad=True)
        
        # Get features for low-confidence samples
        adapted_low = adapted_features[mask]
        original_low = original_features[mask]
        
        if adapted_low.shape[0] < 2:
            return torch.tensor(0.0, device=logits.device, requires_grad=True)
        
        # Compute average pairwise distance from frozen feature space
        with torch.no_grad():
            # Compute pairwise distances
            pairwise_dist_orig = torch.cdist(original_low, original_low, p=2)
            # Mask diagonal
            eye = torch.eye(pairwise_dist_orig.shape[0], device=pairwise_dist_orig.device, dtype=torch.bool)
            pairwise_dist_orig = pairwise_dist_orig.masked_fill(eye, float('inf'))
            d_avg = pairwise_dist_orig.min(dim=-1)[0].mean()
            d_avg = torch.clamp(d_avg, min=1e-8)
        
        # Compute pairwise distances in adapted feature space
        pairwise_dist_adapted = torch.cdist(adapted_low, adapted_low, p=2) ** 2
        
        # Apply temperature scaling
        temperature = 1.0
        scaled_dist = pairwise_dist_adapted / (temperature * d_avg)
        
        # Compute expectation with log-sum-exp trick
        exp_dist = torch.exp(scaled_dist)
        exp_dist = exp_dist.masked_fill(eye, 0)
        
        num_pairs = adapted_low.shape[0] * (adapted_low.shape[0] - 1)
        if num_pairs > 0:
            expectation = exp_dist.sum() / num_pairs
            log_expectation = torch.log(expectation + 1e-8)
        else:
            log_expectation = torch.tensor(0.0, device=logits.device)
        
        return log_expectation - 1.0
    
    @torch.enable_grad()
    def forward_and_adapt(self, x):
        """
        Forward pass with confidence-aware adaptation
        
        Args:
            x: Input batch (images, ...)
            
        Returns:
            logits: Model predictions
        """
        imgs_test = x[0]
        
        # Forward pass through DIRE model
        if hasattr(self.model, 'encode_image'):
            # DIRE model interface
            img_features = self.model.encode_image(imgs_test)
            
            # ==================== 修改：正确获取冻结编码器特征 ====================
            if self.frozen_encoder is not None:
                with torch.no_grad():
                    # ✅ 预处理图像至 256×256 再传入冻结编码器
                    preprocessed_imgs = self._preprocess_for_frozen_encoder(imgs_test)
                    frozen_outputs = self.frozen_encoder(preprocessed_imgs)
                    
                    # ==================== 修复：处理HuggingFace输出对象 ====================
                    # Extract features from BaseModelOutputWithPooling object
                    if hasattr(frozen_outputs, 'last_hidden_state'):
                        # BaseModelOutputWithPooling object
                        frozen_features = frozen_outputs.last_hidden_state
                    elif hasattr(frozen_outputs, 'pooler_output') and frozen_outputs.pooler_output is not None:
                        # Directly use pooled output
                        frozen_features = frozen_outputs.pooler_output
                    else:
                        # Fallback: tuple or tensor
                        frozen_features = frozen_outputs[0] if isinstance(frozen_outputs, (tuple, list)) else frozen_outputs
                    
                    # Ensure frozen_features is a tensor
                    if not isinstance(frozen_features, torch.Tensor):
                        raise RuntimeError(f"无法提取有效特征: {type(frozen_features)}")
                    # ===================================================================
                    
                    # 池化：如果是序列特征，取 cls token
                    if frozen_features.ndim == 3:
                        frozen_features = frozen_features[:, 0, :]
            else:
                # 备用方案：使用可训练编码器的输出（无梯度）
                frozen_features = img_features.detach()
            # ===================================================================
            
            # Compute logits
            logit_scale = self.model.logit_scale.exp()
            logits = logit_scale * F.normalize(img_features, dim=-1) @ self.model.text_features.T
        else:
            # Standard forward
            outputs = self.model(imgs_test, return_features=True)
            if isinstance(outputs, tuple):
                logits, img_features, text_features = outputs[:3]
                frozen_features = img_features.detach()
            else:
                logits = outputs
                img_features = logits
                frozen_features = img_features.detach()
        
        # Compute confidence masks
        high_conf_mask, low_conf_mask, predictions, confidences = self.compute_confidence(logits)
        
        # Compute losses
        total_loss = 0.0
        
        # Entropy minimization for high-confidence samples
        if high_conf_mask.any():
            ent_loss = self.entropy_loss(logits, high_conf_mask)
            total_loss = total_loss + self.entropy_weight * ent_loss
            self.losses['entropy'].append(ent_loss.item())
        else:
            self.losses['entropy'].append(0.0)
        
        # Distance-compensated loss for low-confidence samples
        if low_conf_mask.any() and self.distance_compensation_weight > 0:
            dc_loss = self.distance_compensated_loss(
                img_features, frozen_features, logits, low_conf_mask
            )
            total_loss = total_loss + self.distance_compensation_weight * dc_loss
            self.losses['distance'].append(dc_loss.item())
        else:
            self.losses['distance'].append(0.0)
        
        # Track total loss
        self.losses['total'].append(total_loss.item() if isinstance(total_loss, torch.Tensor) else total_loss)
        
        # Backward pass and optimization
        if isinstance(total_loss, torch.Tensor) and total_loss.requires_grad:
            self.optimizer.zero_grad()
            total_loss.backward()
            self.optimizer.step()
            
            # Log adaptation statistics
            if hasattr(self, 'batch_idx') and self.batch_idx % 100 == 0:
                self._log_adaptation_stats(high_conf_mask, low_conf_mask, confidences)
        
        return logits.detach()
    
    def _log_adaptation_stats(self, high_conf_mask, low_conf_mask, confidences):
        """Log adaptation statistics"""
        total_samples = high_conf_mask.shape[0]
        high_conf_count = high_conf_mask.sum().item()
        low_conf_count = low_conf_mask.sum().item()
        avg_confidence = confidences.mean().item()
        
        logger.info(f"Batch {self.batch_idx}: "
                   f"High-conf: {high_conf_count}/{total_samples} ({high_conf_count/total_samples*100:.1f}%), "
                   f"Low-conf: {low_conf_count}/{total_samples} ({low_conf_count/total_samples*100:.1f}%), "
                   f"Avg confidence: {avg_confidence:.3f}")
    
    def configure_model(self):
        """
        Configure model for adaptation.
        Only adapt LayerNorm parameters in DiT blocks.
        """
        self.model.eval()
        
        # Freeze all parameters first
        self.model.requires_grad_(False)
        
        # Enable gradients only for specific layers
        for name, module in self.model.named_modules():
            # Adapt LayerNorm in DiT blocks
            if 'dit_blocks' in name and isinstance(module, (nn.LayerNorm, nn.GroupNorm)):
                module.train()
                module.requires_grad_(True)
                for p in module.parameters():
                    p.requires_grad = True
            
            # Also adapt any BatchNorm layers for stability
            elif isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d)):
                module.train()
                module.requires_grad_(True)
                module.track_running_stats = False
                module.running_mean = None
                module.running_var = None
                for p in module.parameters():
                    p.requires_grad = True
        
        # Log adapted parameters
        adapted_params = []
        for name, param in self.model.named_parameters():
            if param.requires_grad:
                adapted_params.append(name)
        
        logger.info(f"Adapted parameters ({len(adapted_params)}):")
        for name in adapted_params[:10]:
            logger.info(f"  {name}")
        if len(adapted_params) > 10:
            logger.info(f"  ... and {len(adapted_params) - 10} more")
    
    def collect_params(self):
        """
        Collect parameters that should be optimized
        
        Returns:
            params: List of parameters to optimize
            names: List of parameter names
        """
        params = []
        names = []
        
        for name, module in self.model.named_modules():
            # Collect LayerNorm parameters in DiT blocks
            if 'dit_blocks' in name and isinstance(module, (nn.LayerNorm, nn.GroupNorm)):
                for param_name, param in module.named_parameters():
                    if param.requires_grad:
                        params.append(param)
                        names.append(f"{name}.{param_name}")
            
            # Collect BatchNorm parameters
            elif isinstance(module, (nn.BatchNorm1d, nn.BatchNorm2d)):
                for param_name, param in module.named_parameters():
                    if param.requires_grad:
                        params.append(param)
                        names.append(f"{name}.{param_name}")
        
        logger.info(f"Collected {len(params)} parameters for optimization")
        return params, names
    
    def reset(self):
        """Reset method"""
        super().reset()
        # Reset loss tracking
        self.losses = {
            'total': [],
            'entropy': [],
            'distance': []
        }