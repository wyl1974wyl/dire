#!/usr/bin/env python
"""
methods/siglip_source.py - SigLIP Source Baseline 专用适配器
避免使用通用基类的复杂逻辑
"""

import torch
import torch.nn as nn
import logging

from methods.source import Source
from utils.registry import ADAPTATION_REGISTRY

logger = logging.getLogger(__name__)


@ADAPTATION_REGISTRY.register()
class SigLIPSource(Source):
    """
    SigLIP2 Source baseline - 直接传递输入给模型
    """
    
    def forward(self, x):
        """
        前向传播：直接调用模型，不修改输入类型
        支持 PIL Image 列表或张量输入
        """
        # 直接传递给 SigLIP2Wrapper，保持原始类型
        return self.model(x)
    
    def forward_and_adapt(self, x):
        """Source 方法不执行适配"""
        return self.forward(x)
    
    def configure_model(self):
        """配置模型为评估模式"""
        self.model.eval()
        self.model.requires_grad_(False)
        logger.info("✅ SigLIPSource: Model configured in eval mode (no adaptation)")