# methods/__init__.py
# 在文件开头强制导入 DIRE，确保注册发生

# 导入基础类
from methods.base import TTAMethod, forward_decorator

# 导入所有标准方法
from methods.source import Source
from methods.norm import BNTest, BNAlpha, BNEMA
from methods.tent import Tent
from methods.sar import SAR
from methods.eata import EATA
from methods.lame import LAME
from methods.rmt import RMT
from methods.memo import MEMO
from methods.cotta import CoTTA
from methods.adacontrast import AdaContrast
from methods.gtta import GTTA
from methods.rotta import RoTTA
from methods.rpl import RPL
from methods.roid import ROID
from methods.santa import SANTA
from methods.cmf import CMF
from methods.deyo import DeYO
from methods.tpt import TPT
from methods.vte import VTE
from methods.siglip_source import SigLIPSource
from methods.dire import DIRE
