#!/bin/bash

set -e

DATASET=${1:-"imagenet_c"}
SEVERITY=${2:-5}
GPU_ID=${3:-0}
CFG=${4:-"cfgs/${DATASET}/dire.yaml"}
DIT_PATH=${5:-"./ckpt/block0.pt"}

TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_BASE="./output"
OUTPUT_DIR="${OUTPUT_BASE}/dire_${DATASET}_severity${SEVERITY}_${TIMESTAMP}"
mkdir -p "$OUTPUT_DIR"

LOG_FILE="${OUTPUT_DIR}/run_all.log"
exec > >(tee -a "$LOG_FILE")
exec 2>&1

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}========== DIRE ==========${NC}"
echo "$DATASET"
echo "$SEVERITY"
echo "$GPU_ID"
echo " $CFG"
echo "$DIT_PATH"
echo "$OUTPUT_DIR"
echo "$LOG_FILE"
echo -e "${BLUE}====================================${NC}"

if [ ! -f "$CFG" ]; then
    echo -e "${RED}: $CFG${NC}"
    exit 1
fi

if [ ! -f "$DIT_PATH" ]; then
    echo -e "${RED}: $DIT_PATH${NC}"
    echo "python download_dit.py --source hf --output-dir ./ckpt"
    exit 1
fi

echo -e "${YELLOW}DiT...${NC}"
if python -c "
import sys
sys.path.insert(0, '.')
from models.dit_block import create_dit_block_from_pretrained
block = create_dit_block_from_pretrained('$DIT_PATH', block_idx=0)
print('✅')
"; then
    echo -e "${GREEN}✅ DiT ${NC}"
else
    echo -e "${RED}❌ DiT ${NC}"
    exit 1
fi

case $DATASET in
    "imagenet_c"|"cifar10_c"|"cifar100_c")
        CORRUPTIONS=(
            "gaussian_noise" "shot_noise" "impulse_noise"
            "defocus_blur" "glass_blur" "motion_blur" "zoom_blur"
            "snow" "frost" "fog" "brightness" "contrast"
            "elastic_transform" "pixelate" "jpeg_compression"
        )
        ;;
    *)

        exit 1
        ;;
esac


STATE_FILE="${OUTPUT_DIR}/state.txt"
COMPLETED_FILE="${OUTPUT_DIR}/completed.txt"
FAILED_FILE="${OUTPUT_DIR}/failed.txt"


if [ -f "$COMPLETED_FILE" ]; then
    COMPLETED_LIST=$(cat "$COMPLETED_FILE")
else
    COMPLETED_LIST=""
fi

if [ -f "$FAILED_FILE" ]; then
    FAILED_LIST=$(cat "$FAILED_FILE")
else
    FAILED_LIST=""
fi


TOTAL_CORRUPTIONS=${#CORRUPTIONS[@]}
COMPLETED=0
FAILED=0
SKIPPED=0

for CORRUPTION in "${CORRUPTIONS[@]}"; do

    if echo "$COMPLETED_LIST" | grep -q "^${CORRUPTION}$"; then
        echo -e "${YELLOW}: ${CORRUPTION}${NC}"
        ((SKIPPED++))
        continue
    fi

    if echo "$FAILED_LIST" | grep -q "^${CORRUPTION}$"; then
        echo -e "${YELLOW}: ${CORRUPTION}${NC}"
    fi
    
    ((COMPLETED++))
    echo -e "\n${BLUE}[${COMPLETED}/${TOTAL_CORRUPTIONS}] : ${CORRUPTION}${NC}"

    CORRUPTION_DIR="${OUTPUT_DIR}/${CORRUPTION}_severity${SEVERITY}"
    mkdir -p "$CORRUPTION_DIR"

    CMD="python run_dire.py \
        --cfg $CFG \
        --dit-path $DIT_PATH \
        --corruption $CORRUPTION \
        --severity $SEVERITY \
        --gpu $GPU_ID \
        --output-dir $CORRUPTION_DIR"
    
    echo ": $CMD" >> "$CORRUPTION_DIR/command.txt"
    echo "$CMD" | bash
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ : ${CORRUPTION}${NC}"
        echo "$CORRUPTION" >> "$COMPLETED_FILE"

        if [ -f "$FAILED_FILE" ]; then
            grep -v "^${CORRUPTION}$" "$FAILED_FILE" > "${FAILED_FILE}.tmp" && mv "${FAILED_FILE}.tmp" "$FAILED_FILE"
        fi
    else
        echo -e "${RED}❌ : ${CORRUPTION}${NC}"
        echo "$CORRUPTION" >> "$FAILED_FILE"
        ((FAILED++))
        
        if [ -f "$CORRUPTION_DIR/log.txt" ]; then
            cp "$CORRUPTION_DIR/log.txt" "$CORRUPTION_DIR/error_$(date +%H%M%S).txt"
        fi

        echo "Ctrl+C..."
        sleep 5
    fi
    
    echo "----------------------------------------" >> "$LOG_FILE"
done

echo -e "\n${BLUE}========== ok ==========${NC}"
if [ $FAILED -gt 0 ]; then
    echo -e "${RED}: $(cat "$FAILED_FILE" 2>/dev/null | wc -l)${NC}"
fi
echo -e "${BLUE}================================${NC}"

cat > "${OUTPUT_DIR}/summary.txt" << EOF
DIRE
====================
${DATASET}
${SEVERITY}
$(date)
${TOTAL_CORRUPTIONS}
$(cat "$COMPLETED_FILE" 2>/dev/null | wc -l)
$(cat "$FAILED_FILE" 2>/dev/null | wc -l)
${SKIPPED}

${OUTPUT_DIR}
${CFG}
${DIT_PATH}

./run_all_corruptions.sh ${DATASET} ${SEVERITY} ${GPU_ID} ${CFG} ${DIT_PATH}

EOF

if [ -f "$FAILED_FILE" ] && [ $(cat "$FAILED_FILE" | wc -l) -gt 0 ]; then
    exit 1
fi