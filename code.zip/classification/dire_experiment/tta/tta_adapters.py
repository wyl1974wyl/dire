"""
TTA - 
tokenizer
"""
import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.optim import AdamW
from tqdm import tqdm
from .tta_losses import ConfidenceAwareTTALoss, BATCLIPLoss
from configs.config import TTA_CONFIG, MODEL_CONFIG
class OnlineTTAAdapter:
    def __init__(self, 
                 model,
                 processor,
                 class_names,
                 confidence_threshold=0.8,
                 learning_rate=5e-4,
                 optimizer_name='AdamW',
                 entropy_weight=1.0,
                 projection_weight=1.0,
                 separability_weight=1.0,
                 distance_weight=1.0,
                 use_dire=True):
        self.model = model
        self.processor = processor
        self.class_names = class_names
        self.use_dire = use_dire
        self.text_prompts = [f"a photo of a {name}." for name in class_names]
        self._precompute_text_features()
        if use_dire:
            self.criterion = ConfidenceAwareTTALoss(
                confidence_threshold=confidence_threshold,
                entropy_weight=entropy_weight,
                projection_weight=projection_weight,
                separability_weight=separability_weight,
                distance_weight=distance_weight
            )
        else:
            self.criterion = BATCLIPLoss(
                entropy_weight=entropy_weight,
                projection_weight=projection_weight,
                separability_weight=separability_weight
            )
        self._setup_optimizer(learning_rate, optimizer_name)
        self._save_original_state()
    def _precompute_text_features(self):
        """（）"""
        self.model.eval()
        with torch.no_grad():
            batch_size = 100
            all_features = []
            for i in range(0, len(self.text_prompts), batch_size):
                batch_prompts = self.text_prompts[i:i+batch_size]
                inputs = self.processor(
                    text=batch_prompts,
                    padding="max_length",
                    max_length=64,
                    return_tensors="pt"
                ).to(self.model.device)
                text_features = self.model.get_text_features(
                    input_ids=inputs['input_ids'],
                    attention_mask=inputs.get('attention_mask')
                )
                all_features.append(text_features.cpu())
            self.text_features = torch.cat(all_features).to(self.model.device)
    def _setup_optimizer(self, learning_rate, optimizer_name):
        """，LayerNorm"""
        trainable_params = []
        for name, param in self.model.named_parameters():
            if 'layer_norm' in name.lower() or 'norm' in name.lower():
                if param.requires_grad:
                    trainable_params.append(param)
        if optimizer_name == 'AdamW':
            self.optimizer = AdamW(trainable_params, lr=learning_rate)
        else:
            raise ValueError(f"Unsupported optimizer: {optimizer_name}")
    def _save_original_state(self):
        """"""
        self.original_state = {}
        for name, param in self.model.named_parameters():
            if 'layer_norm' in name.lower() or 'norm' in name.lower():
                self.original_state[name] = param.data.clone()
    def reset_parameters(self):
        """"""
        for name, param in self.model.named_parameters():
            if name in self.original_state:
                param.data.copy_(self.original_state[name])
    def adapt_batch(self, images, labels=None, return_predictions=False):
        """batch"""
        B = images.shape[0]
        device = self.model.device
        with torch.enable_grad():
            image_features = self.model.get_vision_features(images)
            image_features_norm = F.normalize(image_features, dim=-1)
            text_features_norm = F.normalize(self.text_features, dim=-1)
            logits = 10.0 * image_features_norm @ text_features_norm.t()
            _, pseudo_labels = torch.max(logits, dim=-1)
            frozen_features = None
            if self.use_dire and hasattr(self.model.vision_encoder, 'siglip2_vision'):
                with torch.no_grad():
                    frozen_outputs = self.model.vision_encoder.siglip2_vision(images)
                    frozen_features = frozen_outputs.pooler_output
            if self.use_dire:
                loss, loss_components = self.criterion(
                    logits=logits,
                    image_features=image_features,
                    text_features=self.text_features,
                    pseudo_labels=pseudo_labels,
                    frozen_features=frozen_features,
                    return_components=True
                )
            else:
                loss = self.criterion(
                    logits=logits,
                    image_features=image_features,
                    text_features=self.text_features,
                    pseudo_labels=pseudo_labels
                )
                loss_components = {'total': loss.item()}
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
        results = {'loss': loss.item(), 'loss_components': loss_components}
        if return_predictions:
            results['predictions'] = pseudo_labels
            results['probabilities'] = F.softmax(logits, dim=-1)
            if labels is not None:
                accuracy = (pseudo_labels == labels).float().mean().item()
                results['accuracy'] = accuracy
        return results
    def adapt_dataloader(self, dataloader, desc="Adapting"):
        """"""
        self.model.train()
        total_losses = {}
        num_batches = 0
        pbar = tqdm(dataloader, desc=desc, leave=False)
        for batch_idx, (images, labels) in enumerate(pbar):
            images = images.to(self.model.device)
            labels = labels.to(self.model.device) if labels is not None else None
            results = self.adapt_batch(images, labels, return_predictions=False)
            for key, value in results['loss_components'].items():
                if key not in total_losses:
                    total_losses[key] = 0.0
                total_losses[key] += value
            num_batches += 1
            pbar.set_postfix({
                'Loss': f"{results['loss']:.4f}",
                'Batch': f"{batch_idx+1}/{len(dataloader)}"
            })
        avg_losses = {k: v / num_batches for k, v in total_losses.items()}
        return avg_losses
    def evaluate_dataloader(self, dataloader, desc="Evaluating"):
        """"""
        self.model.eval()
        all_predictions = []
        all_labels = []
        all_probabilities = []
        with torch.no_grad():
            pbar = tqdm(dataloader, desc=desc, leave=False)
            for batch_idx, (images, labels) in enumerate(pbar):
                try:
                    images = images.to(self.model.device)
                    labels = labels.to(self.model.device)
                    image_features = self.model.get_vision_features(images)
                    image_features_norm = F.normalize(image_features, dim=-1)
                    text_features_norm = F.normalize(self.text_features, dim=-1)
                    logits = 10.0 * image_features_norm @ text_features_norm.t()
                    probabilities = F.softmax(logits, dim=-1)
                    predictions = torch.argmax(logits, dim=-1)
                    all_predictions.append(predictions.cpu())
                    all_labels.append(labels.cpu())
                    all_probabilities.append(probabilities.cpu())
                    if batch_idx % 10 == 0:
                        pbar.set_postfix({'Batch': f"{batch_idx}/{len(dataloader)}"})
                except Exception as e:
                    raise
        all_predictions = torch.cat(all_predictions)
        all_labels = torch.cat(all_labels)
        all_probabilities = torch.cat(all_probabilities)
        accuracy = (all_predictions == all_labels).float().mean().item()
        return {
            'accuracy': accuracy,
            'predictions': all_predictions,
            'labels': all_labels,
            'probabilities': all_probabilities
        }
class AblationTTAAdapter(OnlineTTAAdapter):
    """TTA"""
    def __init__(self, 
                 model,
                 processor,
                 class_names,
                 use_entropy=True,
                 use_projection=True,
                 use_separability=True,
                 use_distance=True,
                 **kwargs):
        entropy_weight = 1.0 if use_entropy else 0.0
        projection_weight = 1.0 if use_projection else 0.0
        separability_weight = 1.0 if use_separability else 0.0
        distance_weight = 1.0 if use_distance else 0.0
        super().__init__(
            model=model,
            processor=processor,
            class_names=class_names,
            entropy_weight=entropy_weight,
            projection_weight=projection_weight,
            separability_weight=separability_weight,
            distance_weight=distance_weight,
            **kwargs
        )
        self.use_entropy = use_entropy
        self.use_projection = use_projection
        self.use_separability = use_separability
        self.use_distance = use_distance