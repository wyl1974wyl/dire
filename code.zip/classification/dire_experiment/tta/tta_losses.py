"""
TTA
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
def entropy_loss(logits):
    """
    （）
    Args:
        logits: [B, C] logits
    Returns:

    """
    probs = F.softmax(logits, dim=-1)
    entropy = -torch.sum(probs * torch.log(probs + 1e-8), dim=-1)
    return torch.mean(entropy)
def projection_matching_loss(image_features, text_features, pseudo_labels):
    """
    （Projection Matching Loss）
    Args:
        image_features: [B, D] 
        text_features: [C, D] （）
        pseudo_labels: [B] 
    Returns:

    """
    B, D = image_features.shape
    C = text_features.shape[0]
    image_features = F.normalize(image_features, dim=-1)
    text_features = F.normalize(text_features, dim=-1)
    prototypes = []
    for c in range(C):
        mask = (pseudo_labels == c).float()
        if mask.sum() > 0:
            prototype = (image_features * mask.unsqueeze(-1)).sum(0) / mask.sum()
        else:
            prototype = torch.zeros(D, device=image_features.device)
        prototypes.append(prototype)
    prototypes = torch.stack(prototypes)
    projections = torch.sum(prototypes * text_features, dim=-1)
    loss = -torch.mean(projections)
    return loss
def inter_class_separability_loss(image_features, pseudo_labels, margin=1.0):
    """
    （Inter-class Separability Loss）
    Args:
        image_features: [B, D] 
        pseudo_labels: [B] 
        margin: 
    Returns:

    """
    B, D = image_features.shape
    C = pseudo_labels.max().item() + 1
    image_features = F.normalize(image_features, dim=-1)
    prototypes = []
    for c in range(C):
        mask = (pseudo_labels == c).float()
        if mask.sum() > 0:
            prototype = (image_features * mask.unsqueeze(-1)).sum(0) / mask.sum()
        else:
            prototype = torch.zeros(D, device=image_features.device)
        prototypes.append(prototype)
    prototypes = torch.stack(prototypes)
    cos_sim = torch.mm(prototypes, prototypes.t())
    mask = 1 - torch.eye(C, device=image_features.device)
    loss = torch.sum(cos_sim * mask) / (C * (C - 1))
    return loss
def distance_compensated_loss(image_features, pseudo_labels, frozen_features, tau=0.8):
    """
    （Distance-Compensated Loss）
    ，
    Args:
        image_features: [B, D] （）
        pseudo_labels: [B] 
        frozen_features: [B, D] （SIGLIP2）
        tau: 
    Returns:

    """
    B, D = image_features.shape
    image_features = F.normalize(image_features, dim=-1)
    frozen_features = F.normalize(frozen_features, dim=-1)
    frozen_dist = torch.cdist(frozen_features, frozen_features, p=2)
    d_avg = frozen_dist.mean()
    current_dist = torch.cdist(image_features, image_features, p=2)
    exp_term = torch.exp(current_dist.pow(2) / (tau * d_avg))
    loss = torch.log(exp_term.mean()) - 1.0
    return loss
class ConfidenceAwareTTALoss(nn.Module):
    """
    TTA
    """
    def __init__(self, 
                 confidence_threshold=0.8,
                 entropy_weight=1.0,
                 projection_weight=1.0,
                 separability_weight=1.0,
                 distance_weight=1.0):
        super().__init__()
        self.confidence_threshold = confidence_threshold
        self.entropy_weight = entropy_weight
        self.projection_weight = projection_weight
        self.separability_weight = separability_weight
        self.distance_weight = distance_weight
    def forward(self, 
                logits,
                image_features,
                text_features,
                pseudo_labels,
                frozen_features=None,
                return_components=False):
        """
        Args:
            logits: [B, C] logits
            image_features: [B, D] 
            text_features: [C, D] 
            pseudo_labels: [B] 
            frozen_features: [B, D] （distance_compensated_loss）
            return_components: 
        Returns:

        """
        probs = F.softmax(logits, dim=-1)
        max_probs, _ = torch.max(probs, dim=-1)
        high_conf_mask = max_probs >= self.confidence_threshold
        low_conf_mask = max_probs < self.confidence_threshold
        total_loss = 0.0
        components = {}
        if high_conf_mask.sum() > 0:
            high_conf_logits = logits[high_conf_mask]
            entropy = entropy_loss(high_conf_logits)
            total_loss += self.entropy_weight * entropy
            components['entropy'] = entropy.item()
        else:
            components['entropy'] = 0.0
        projection = projection_matching_loss(image_features, text_features, pseudo_labels)
        total_loss += self.projection_weight * projection
        components['projection'] = projection.item()
        separability = inter_class_separability_loss(image_features, pseudo_labels)
        total_loss += self.separability_weight * separability
        components['separability'] = separability.item()
        if low_conf_mask.sum() > 0 and frozen_features is not None:
            low_conf_features = image_features[low_conf_mask]
            low_conf_frozen = frozen_features[low_conf_mask]
            distance = distance_compensated_loss(low_conf_features, 
                                               pseudo_labels[low_conf_mask], 
                                               low_conf_frozen)
            total_loss += self.distance_weight * distance
            components['distance'] = distance.item()
        else:
            components['distance'] = 0.0
        if return_components:
            return total_loss, components
        return total_loss
class BATCLIPLoss(nn.Module):
    """
    BATCLIP（）
     +  + 
    """
    def __init__(self, 
                 entropy_weight=1.0,
                 projection_weight=1.0,
                 separability_weight=1.0):
        super().__init__()
        self.entropy_weight = entropy_weight
        self.projection_weight = projection_weight
        self.separability_weight = separability_weight
    def forward(self, logits, image_features, text_features, pseudo_labels):
        """
        Args:
            logits: [B, C] logits
            image_features: [B, D] 
            text_features: [C, D] 
            pseudo_labels: [B] 
        Returns:

        """
        total_loss = 0.0
        entropy = entropy_loss(logits)
        total_loss += self.entropy_weight * entropy
        projection = projection_matching_loss(image_features, text_features, pseudo_labels)
        total_loss += self.projection_weight * projection
        separability = inter_class_separability_loss(image_features, pseudo_labels)
        total_loss += self.separability_weight * separability
        return total_loss