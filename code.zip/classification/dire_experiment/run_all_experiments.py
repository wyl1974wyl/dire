"""
：
1. SIGLIP2
2. SIGLIP2+DIT
3. SIGLIP2+DIT+TTA
4. TTA
"""
import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
import subprocess
import argparse
from datetime import datetime
import json
def run_command(cmd, desc=""):
    """"""
    result = subprocess.run(cmd, shell=True, capture_output=False)
    if result.returncode != 0:
        return False
    return True
def main():
    parser = argparse.ArgumentParser(description='Run all DIRE experiments')
    parser.add_argument('--dit_ckpt', type=str, default='./ckpt/block0.pt',
                        help='Path to DIT checkpoint')
    parser.add_argument('--results_dir', type=str, default='./results',
                        help='Results directory')
    parser.add_argument('--datasets', nargs='+', default=['cifar10', 'cifar100', 'imagenet'],
                        choices=['cifar10', 'cifar100', 'imagenet'],
                        help='Datasets to run experiments on')
    parser.add_argument('--skip_ablation', action='store_true',
                        help='Skip ablation experiments')
    parser.add_argument('--severity', type=int, default=5,
                        choices=[1, 2, 3, 4, 5],
                        help='Corruption severity level')
    args = parser.parse_args()
    os.makedirs(args.results_dir, exist_ok=True)
    experiments = []
    for dataset in args.datasets:
        experiments.append({
            'desc': f"SIGLIP2 zero-shot on {dataset}",
            'cmd': f"python main_experiment_fixed.py --dataset {dataset} --model siglip2 --severity {args.severity} --results_dir {args.results_dir}"
        })
        experiments.append({
            'desc': f"SIGLIP2+DIT zero-shot on {dataset}",
            'cmd': f"python main_experiment_fixed.py --dataset {dataset} --model dire --severity {args.severity} --dit_ckpt {args.dit_ckpt} --results_dir {args.results_dir}"
        })
        experiments.append({
            'desc': f"SIGLIP2+DIT+TTA on {dataset}",
            'cmd': f"python main_experiment_fixed.py --dataset {dataset} --model dire --tta --severity {args.severity} --dit_ckpt {args.dit_ckpt} --results_dir {args.results_dir}"
        })
    if not args.skip_ablation:
        experiments.append({
            'desc': f"Ablation experiments on cifar10",
            'cmd': f"python main_experiment_fixed.py --dataset cifar10 --ablation --severity {args.severity} --results_dir {args.results_dir}"
        })
    total_experiments = len(experiments)
    completed = 0
    failed = []
    for i, exp in enumerate(experiments, 1):

        success = run_command(exp['cmd'], exp['desc'])
        if success:
            completed += 1
        else:
            failed.append(exp['desc'])
    if failed:
        for f in failed:
            pass

    generate_summary_report(args.results_dir)
def generate_summary_report(results_dir):
    """"""
    result_files = [f for f in os.listdir(results_dir) if f.endswith('.json')]
    if not result_files:
        return
    summary = {
        'experiments': {},
        'summary_stats': {}
    }
    for result_file in result_files:
        filepath = os.path.join(results_dir, result_file)
        try:
            with open(filepath, 'r') as f:
                data = json.load(f)
            if isinstance(data, list) and len(data) > 0:
                exp = data[0]
                key = f"{exp['dataset']}_{exp['model']}"
                if exp['tta']:
                    key += "_tta"
                if key not in summary['experiments']:
                    summary['experiments'][key] = []
                summary['experiments'][key].extend(data)
        except Exception as e:
            continue
    for exp_key, results in summary['experiments'].items():
        accuracies = [r['accuracy'] for r in results if 'accuracy' in r]
        if accuracies:
            summary['summary_stats'][exp_key] = {
                'mean_accuracy': np.mean(accuracies),
                'std_accuracy': np.std(accuracies),
                'min_accuracy': np.min(accuracies),
                'max_accuracy': np.max(accuracies),
                'num_corruptions': len(accuracies)
            }
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    summary_file = os.path.join(results_dir, f"summary_{timestamp}.json")
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    for exp_key, stats in summary['summary_stats'].items():
        pass

if __name__ == '__main__':
    import numpy as np
    main()