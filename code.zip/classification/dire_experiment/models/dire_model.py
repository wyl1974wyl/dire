import os
import torch
import torch.nn as nn
from transformers import AutoModel, AutoProcessor
from .dit_block import DiTBlock, load_dit_block_from_checkpoint
from configs.config import MODEL_CONFIG


class SIGLIP2DiTEncoder(nn.Module):

    def __init__(self, 
                 siglip2_model_name="google/siglip2-base-patch16-256",
                 dit_ckpt_path=None,
                 freeze_siglip2=True):
        super().__init__()

        self.freeze_siglip2 = freeze_siglip2

        full_model = AutoModel.from_pretrained(
            siglip2_model_name,
            cache_dir="<CACHE_DIR>"
        )

        self.siglip2_vision = full_model.vision_model

        self.hidden_size = self.siglip2_vision.config.hidden_size

        if dit_ckpt_path and os.path.exists(dit_ckpt_path):
            self.dit_block = load_dit_block_from_checkpoint(dit_ckpt_path)
        else:
            self.dit_block = DiTBlock(
                hidden_size=self.hidden_size,
                num_heads=12
            )

        for name, param in self.dit_block.named_parameters():
            if 'norm' not in name.lower():
                param.requires_grad = False

        if self.freeze_siglip2:
            for param in self.siglip2_vision.parameters():
                param.requires_grad = False

            for name, param in self.siglip2_vision.named_parameters():
                if 'layer_norm' in name.lower() or 'norm' in name.lower():
                    param.requires_grad = True

        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        total_params = sum(p.numel() for p in self.parameters())

    def forward(self, pixel_values, **kwargs):

        with torch.set_grad_enabled(not self.freeze_siglip2):
            vision_outputs = self.siglip2_vision(pixel_values, **kwargs)
            features = vision_outputs.pooler_output

        features = features.unsqueeze(1)
        features = self.dit_block(features)
        features = features.squeeze(1)

        return features


class SIGLIP2TextEncoder(nn.Module):

    def __init__(self, model_name="google/siglip2-base-patch16-256"):
        super().__init__()

        full_model = AutoModel.from_pretrained(
            model_name,
            cache_dir="<CACHE_DIR>"
        )

        self.siglip2_text = full_model.text_model

        for param in self.siglip2_text.parameters():
            param.requires_grad = False

    def forward(self, input_ids, attention_mask=None, **kwargs):

        with torch.no_grad():
            outputs = self.siglip2_text(
                input_ids=input_ids,
                attention_mask=attention_mask,
                **kwargs
            )
            return outputs.last_hidden_state[:, 0, :]


class DIREModel(nn.Module):

    def __init__(self, 
                 siglip2_model_name="google/siglip2-base-patch16-256",
                 dit_ckpt_path=None):
        super().__init__()

        self.vision_encoder = SIGLIP2DiTEncoder(
            siglip2_model_name=siglip2_model_name,
            dit_ckpt_path=dit_ckpt_path,
            freeze_siglip2=True,
        )

        self.text_encoder = SIGLIP2TextEncoder(model_name=siglip2_model_name)

        self.logit_scale = nn.Parameter(torch.ones([]) * 10.0)

        self.processor = AutoProcessor.from_pretrained(siglip2_model_name)

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    def get_vision_features(self, pixel_values, **kwargs):

        return self.vision_encoder(pixel_values, **kwargs)

    def get_text_features(self, input_ids, attention_mask=None, **kwargs):

        return self.text_encoder(input_ids, attention_mask, **kwargs)

    def forward(self, pixel_values, input_ids, attention_mask=None, **kwargs):

        image_embeds = self.get_vision_features(pixel_values, **kwargs)
        text_embeds = self.get_text_features(input_ids, attention_mask, **kwargs)

        image_embeds = image_embeds / image_embeds.norm(dim=-1, keepdim=True)
        text_embeds = text_embeds / text_embeds.norm(dim=-1, keepdim=True)

        logit_scale = self.logit_scale.exp()
        logits_per_image = logit_scale * image_embeds @ text_embeds.t()
        logits_per_text = logits_per_image.t()

        return {
            'logits_per_image': logits_per_image,
            'logits_per_text': logits_per_text,
            'image_embeds': image_embeds,
            'text_embeds': text_embeds
        }


class SimpleSIGLIP2Model(nn.Module):

    def __init__(self, model_name="google/siglip2-base-patch16-256"):
        super().__init__()

        self.model = AutoModel.from_pretrained(
            model_name,
            cache_dir="<CACHE_DIR>"
        )

        for name, param in self.model.named_parameters():
            if 'layer_norm' not in name.lower():
                param.requires_grad = False

        self.processor = AutoProcessor.from_pretrained(model_name)

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    def get_text_features(self, input_ids, attention_mask=None, **kwargs):

        return self.model.get_text_features(
            input_ids=input_ids,
            attention_mask=attention_mask,
            **kwargs
        )

    def get_vision_features(self, pixel_values, **kwargs):

        return self.model.get_image_features(pixel_values, **kwargs)