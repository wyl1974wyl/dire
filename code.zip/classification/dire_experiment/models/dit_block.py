import torch
import torch.nn as nn
import math
class DiTBlock(nn.Module):

    def __init__(self, hidden_size=768, num_heads=12, dropout=0.0):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.head_dim = hidden_size // num_heads
        self.norm1 = nn.LayerNorm(hidden_size, eps=1e-6)
        self.norm2 = nn.LayerNorm(hidden_size, eps=1e-6)
        self.attn_qkv = nn.Linear(hidden_size, hidden_size * 3, bias=True)
        self.attn_proj = nn.Linear(hidden_size, hidden_size, bias=True)
        mlp_hidden = 2048
        self.mlp_w12 = nn.Linear(hidden_size, mlp_hidden * 2, bias=True)
        self.mlp_w3 = nn.Linear(mlp_hidden, hidden_size, bias=True)
        self.dropout = dropout
    def forward(self, x):

        B, N, D = x.shape
        residual = x
        x = self.norm1(x)
        qkv = self.attn_qkv(x)
        qkv = qkv.reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        attn_scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.head_dim)
        attn_probs = attn_scores.softmax(dim=-1)
        attn_out = (attn_probs @ v).transpose(1, 2).reshape(B, N, D)
        x = residual + self.attn_proj(attn_out)
        residual = x
        x = self.norm2(x)
        mlp_out = self.mlp_w12(x)
        gate, val = mlp_out.chunk(2, dim=-1)
        mlp_out = val * torch.sigmoid(gate)
        mlp_out = self.mlp_w3(mlp_out)
        x = residual + mlp_out
        return x
class DiTBlocks(nn.Module):

    def __init__(self, num_blocks=1, hidden_size=768, num_heads=12, dropout=0.0):
        super().__init__()
        self.blocks = nn.ModuleList([
            DiTBlock(hidden_size, num_heads, dropout=dropout)
            for _ in range(num_blocks)
        ])
    def forward(self, x):
        for block in self.blocks:
            x = block(x)
        return x
def load_dit_block_from_checkpoint(ckpt_path, device='cpu'):

    checkpoint = torch.load(ckpt_path, map_location=device)
    dit_block = DiTBlock(hidden_size=768, num_heads=12)
    if 'model' in checkpoint:
        model_state = checkpoint['model']
        new_state = {}
        for key, value in model_state.items():
                param_name = key.replace('blocks.0.', '')
                if 'attn.qkv' in param_name:
                    new_key = param_name.replace('attn.qkv', 'attn_qkv')
                elif 'attn.proj' in param_name:
                    new_key = param_name.replace('attn.proj', 'attn_proj')
                elif 'mlp.w12' in param_name:
                    new_key = param_name.replace('mlp.w12', 'mlp_w12')
                elif 'mlp.w3' in param_name:
                    new_key = param_name.replace('mlp.w3', 'mlp_w3')
                elif 'norm1' in param_name:
                    new_key = param_name.replace('norm1', 'norm1')
                elif 'norm2' in param_name:
                    new_key = param_name.replace('norm2', 'norm2')
                else:
                    new_key = param_name
                new_state[new_key] = value
        missing, unexpected = dit_block.load_state_dict(new_state, strict=False)
        if missing:
            pass
        if unexpected:
            pass

    else:
        pass

    return dit_block
if __name__ == '__main__':

    block = DiTBlock(hidden_size=768, num_heads=12)
    x = torch.randn(2, 1, 768)
 