import os
import itertools
import random
import argparse
import subprocess
import json
from datetime import datetime
from typing import List, Dict, Any
PARAM_SPACES = {
    'confidence_threshold': {
        'grid': [0.7, 0.8, 0.9, 0.95],
        'random': {'min': 0.5, 'max': 0.95, 'type': 'float'}
    },
    'entropy_weight': {
        'grid': [1.0, 1.5],
        'random': {'min': 0.5, 'max': 2.5, 'type': 'float'}
    },
    'distance_compensated_weight': {
        'grid': [0.02, 0.03, 0.04],
        'random': {'min': 0.1, 'max': 1.5, 'type': 'float'}
    }
}
def generate_grid_params() -> List[Dict[str, float]]:

    keys = list(PARAM_SPACES.keys())
    values = [PARAM_SPACES[k]['grid'] for k in keys]
    combos = []
    for combo in itertools.product(*values):
        param_dict = dict(zip(keys, combo))
        combos.append(param_dict)
    return combos
def generate_random_params(num_samples: int) -> List[Dict[str, float]]:

    combos = []
    for _ in range(num_samples):
        param_dict = {}
        for key, config in PARAM_SPACES.items():
            min_val = config['random']['min']
            max_val = config['random']['max']
            param_type = config['random']['type']
            if param_type == 'float':
                value = random.uniform(min_val, max_val)
                value = round(value, 2)
            else:
                value = random.randint(min_val, max_val)
            param_dict[key] = value
        combos.append(param_dict)
    return combos
def construct_command(params: Dict[str, float], 
                     dataset: str = 'cifar10',
                     model: str = 'dire',
                     dit_ckpt: str = './ckpt/block0.pt',
                     severity: int = 5,
                     results_dir: str = './results') -> str:
    cmd = [
        "python", "main_experiment_fixed.py",
        "--dataset", dataset,
        "--model", model,
        "--tta",
        "--severity", str(severity),
        "--dit_ckpt", dit_ckpt,
        "--results_dir", results_dir
    ]
    for key, value in params.items():
        cmd.extend([f"--{key}", str(value)])
    return " ".join(cmd)
def run_experiment(cmd: str, param_desc: str) -> bool:

    result = subprocess.run(cmd, shell=True)
    if result.returncode != 0:
        return False
    return True
def save_search_log(all_params: List[Dict[str, Any]], 
                    search_type: str,
                    output_dir: str):
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(output_dir, f"hyperparam_search_{search_type}_{timestamp}.json")
    log_data = {
        "search_type": search_type,
        "timestamp": timestamp,
        "total_experiments": len(all_params),
        "parameter_space": PARAM_SPACES,
        "experiments": all_params
    }
    with open(log_file, 'w', encoding='utf-8') as f:
        json.dump(log_data, f, ensure_ascii=False, indent=2)
    return log_file
def main():
    parser = argparse.ArgumentParser(description='Hyperparameter Search for DIRE TTA')
    parser.add_argument('--search_method', type=str, default='grid',
                        choices=['grid', 'random'],
                        help='Search method: grid or random')
    parser.add_argument('--random_samples', type=int, default=20,
                        help='Number of random samples (only for random search)')
    parser.add_argument('--dataset', type=str, default='cifar10',
                        choices=['cifar10', 'cifar100', 'imagenet'],
                        help='Dataset to use')
    parser.add_argument('--model', type=str, default='dire',
                        choices=['siglip2', 'dire'],
                        help='Model type')
    parser.add_argument('--severity', type=int, default=5,
                        choices=[1, 2, 3, 4, 5],
                        help='Corruption severity')
    parser.add_argument('--dit_ckpt', type=str, default='./ckpt/block0.pt',
                        help='Path to DIT checkpoint')
    parser.add_argument('--results_dir', type=str, default='./results/cifar10_2',
                        help='Results directory')
    parser.add_argument('--parallel', type=int, default=1,
                        help='Number of parallel experiments (1=sequential)')
    parser.add_argument('--dry_run', action='store_true',
                        help='Print commands without executing')
    args = parser.parse_args()
    os.makedirs(args.results_dir, exist_ok=True)
    if args.search_method == 'grid':
        all_params = generate_grid_params()
    else:
        all_params = generate_random_params(args.random_samples)
    save_search_log(all_params, args.search_method, args.results_dir)
    completed = 0
    failed = 0
    for i, params in enumerate(all_params, 1):
        param_desc = f"[{i}/{len(all_params)}] " + "_".join([f"{k}={v}" for k, v in params.items()])
        cmd = construct_command(
            params,
            dataset=args.dataset,
            model=args.model,
            dit_ckpt=args.dit_ckpt,
            severity=args.severity,
            results_dir=args.results_dir
        )
        if args.dry_run:
            continue
        success = run_experiment(cmd, param_desc)
        if success:
            completed += 1
        else:
            failed += 1
if __name__ == '__main__':
    main()