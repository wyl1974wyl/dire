# DIRE: Diffusion-Informed Robustness Enhancement for Vision-Language Models

A zero-shot robust image classification framework built on SigLIP2 and DiT (Diffusion Transformer), supporting common corruption benchmarks including ImageNet-C, CIFAR-10, and CIFAR-100, with integrated online test-time adaptation (TTA) and hyperparameter search.

## Project Structure

```
.
├── configs/
│   └── config.py                 # Dataset, model, and experiment configurations
├── models/
│   └── dire_model.py             # DIREModel (SigLIP2 + DiT) and SimpleSIGLIP2Model
├── datasets/
│   └── corruption_datasets_fixed.py  # Corruption dataset loaders (ImageNet-C / CIFAR-10 / CIFAR-100)
├── tta/
│   └── tta_adapters.py           # OnlineTTAAdapter, AblationTTAAdapter
├── ckpt/
│   └── block0.pt                 # Pre-trained DiT block checkpoint
├── main_experiment_fixed.py      # Main experiment entry (single corruption / all corruptions / TTA / ablation)
├── run_all_experiments.py        # Batch runner: SIGLIP2 / SIGLIP2+DIT / SIGLIP2+DIT+TTA
├── hyperparameter_search.py      # Grid / random hyperparameter search for TTA
├── example_usage.py              # Six standalone examples (load, inference, TTA, custom corruption, etc.)
└── results/                      # Experiment result JSON output directory (auto-created)
```

## Requirements

- Python >= 3.10
- PyTorch >= 1.11.0 (CUDA 10.2 compatible)
- CUDA-capable GPU (recommended; CPU fallback supported)

## Installation

```bash
pip install -r requirements.txt
```

For Conda users, the provided `coral.yaml` can be used to recreate the exact environment:

```bash
conda env create -f coral.yaml
conda activate coralscop
```

## Quick Start

### 1. Prepare Data

Place ImageNet-C, CIFAR-10-C, or CIFAR-100-C under any directory, and replace `<DATA_ROOT_PATH>` in `main_experiment_fixed.py` or `example_usage.py` with the actual path. Expected layout:

```
/data/wlb/ImageNet-C/
├── gaussian_noise/
│   ├── 1/
│   ├── 2/
│   ├── 3/
│   ├── 4/
│   └── 5/
├── shot_noise/
│   └── ...
└── brightness/
    └── ...
```

### 2. Run a Single Experiment

**SIGLIP2 zero-shot baseline (CIFAR-10, gaussian_noise, severity=5):**
```bash
python main_experiment_fixed.py   --dataset cifar10   --model siglip2   --corruption gaussian_noise   --severity 5   --results_dir ./results
```

**DIRE (SigLIP2 + DiT) zero-shot:**
```bash
python main_experiment_fixed.py   --dataset cifar10   --model dire   --corruption gaussian_noise   --severity 5   --dit_ckpt ./ckpt/block0.pt   --results_dir ./results
```

**DIRE + TTA:**
```bash
python main_experiment_fixed.py   --dataset cifar10   --model dire   --tta   --corruption gaussian_noise   --severity 5   --dit_ckpt ./ckpt/block0.pt   --results_dir ./results
```

**Run all 15 corruption types (omit `--corruption`):**
```bash
python main_experiment_fixed.py   --dataset cifar10   --model dire   --tta   --severity 5   --dit_ckpt ./ckpt/block0.pt   --results_dir ./results
```

### 3. Batch Run All Experiments

```bash
python run_all_experiments.py   --datasets cifar10 cifar100 imagenet   --dit_ckpt ./ckpt/block0.pt   --results_dir ./results   --severity 5
```

This sequentially executes:
1. SIGLIP2 zero-shot
2. SIGLIP2 + DiT zero-shot
3. SIGLIP2 + DiT + TTA

An automatic summary report `summary_*.json` is generated under `results/`.

### 4. TTA Hyperparameter Search

**Grid search:**
```bash
python hyperparameter_search.py   --search_method grid   --dataset cifar10   --model dire   --severity 5   --dit_ckpt ./ckpt/block0.pt   --results_dir ./results
```

**Random search (20 trials):**
```bash
python hyperparameter_search.py   --search_method random   --random_samples 20   --dataset cifar10   --model dire   --severity 5   --dit_ckpt ./ckpt/block0.pt   --results_dir ./results
```

Tunable hyperparameters:
- `confidence_threshold`: confidence threshold (default 0.8)
- `entropy_weight`: entropy regularization weight (default 1.0)
- `distance_compensated_weight`: distance compensation weight (default 1.0)

### 5. Standalone Example Script

```bash
python example_usage.py
```

Contains six example functions:
- `example_1_load_model`: load DIREModel
- `example_2_load_dataset`: load corruption dataset
- `example_3_zero_shot_inference`: zero-shot inference
- `example_4_tta_adaptation`: online TTA adaptation
- `example_5_custom_corruption`: custom Gaussian corruption
- `example_6_batch_processing`: batch process multiple corruptions

## Command-Line Arguments (main_experiment_fixed.py)

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `--dataset` | str | **required** | `imagenet`, `cifar10`, `cifar100` |
| `--model` | str | `dire` | `siglip2` or `dire` |
| `--tta` | flag | False | enable online TTA |
| `--ablation` | flag | False | run ablation experiment |
| `--corruption` | str | None | specific corruption type; None runs all |
| `--severity` | int | 5 | corruption level 1–5 |
| `--dit_ckpt` | str | `./ckpt/block0.pt` | DiT checkpoint path |
| `--results_dir` | str | `./results` | result save directory |
| `--confidence_threshold` | float | None | override default confidence threshold |
| `--entropy_weight` | float | None | override default entropy weight |
| `--distance_compensated_weight` | float | None | override default distance compensation weight |

## Output Format

Each experiment writes a JSON file with the following structure:

```json
[
  {
    "dataset": "cifar10",
    "model": "dire",
    "tta": true,
    "corruption": "gaussian_noise",
    "severity": 5,
    "num_samples": 10000,
    "accuracy": 0.8234,
    "hyperparameters": {
      "confidence_threshold": 0.8,
      "entropy_weight": 1.0,
      "distance_compensated_weight": 1.0
    }
  }
]
```

`run_all_experiments.py` additionally produces `summary_*.json`, aggregating mean / std / min / max per configuration.

## Notes

- The first run will automatically download `google/siglip2-base-patch16-256` from HuggingFace; ensure network access or set up a local cache.
- `TOKENIZERS_PARALLELISM=false` is already set in scripts to suppress tokenizer parallelism warnings.
- For ImageNet experiments, consider setting `num_workers > 0` to accelerate data loading (CIFAR series use `num_workers=0` to avoid multiprocessing issues).
- The `dit_shortcut` switch, when enabled, bypasses the DiT block so the DIRE model outputs raw SigLIP2 features directly, useful for quick baseline comparisons.

## Citation

If this project is helpful to your work, please cite:

```bibtex
@inproceedings{your_icml_2026_paper,
  title={DIRE: Diffusion-Informed Robustness Enhancement for Vision-Language Models},
  author={...},
  booktitle={ICML},
  year={2026}
}
```

## License

MIT License
