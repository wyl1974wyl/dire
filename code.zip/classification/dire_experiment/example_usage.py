import sys
import os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import torch
import numpy as np
from PIL import Image
from models.dire_model import DIREModel
from datasets.corruption_datasets import get_corruption_dataloader, get_dataset_transform
from tta.tta_adapters import OnlineTTAAdapter
from configs.config import DATASET_CONFIG
def example_1_load_model():

    model = DIREModel(
        siglip2_model_name="google/siglip2-base-patch16-256",
        num_dit_blocks=4,
        dit_ckpt_path = "<CKPT_PATH>"
    )
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)
    return model
def example_2_load_dataset():

    dataloader = get_corruption_dataloader(
        dataset_name='cifar10',
        corruption_type='gaussian_noise',
        severity=5,
        batch_size=32,
        data_root = "<DATA_ROOT_PATH>"  
    )
    for images, labels in dataloader:
        break
    return dataloader
def example_3_zero_shot_inference(model, dataloader):

    model.eval()
    all_predictions = []
    all_labels = []
    class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 
                   'dog', 'frog', 'horse', 'ship', 'truck']
    text_prompts = [f"a photo of a {name}." for name in class_names]
    with torch.no_grad():
        for i, (images, labels) in enumerate(dataloader):
            images = images.to(model.device)
            text_inputs = model.processor(
                text=text_prompts,
                padding="max_length",
                max_length=64,
                return_tensors="pt"
            ).to(model.device)
            outputs = model(
                pixel_values=images,
                input_ids=text_inputs.input_ids,
                attention_mask=text_inputs.attention_mask
            )
            logits = outputs['logits_per_image']
            predictions = torch.argmax(logits, dim=-1)
            all_predictions.append(predictions.cpu())
            all_labels.append(labels)
            if i >= 2:
                break
    all_predictions = torch.cat(all_predictions)
    all_labels = torch.cat(all_labels)
    accuracy = (all_predictions == all_labels).float().mean().item()
    return accuracy
def example_4_tta_adaptation(model, dataloader):

    class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 
                   'dog', 'frog', 'horse', 'ship', 'truck']
    tta_adapter = OnlineTTAAdapter(
        model=model,
        processor=model.processor,
        class_names=class_names,
        confidence_threshold=0.8,
        learning_rate=5e-4
    )
    tta_adapter.reset_parameters()
    for images, labels in dataloader:
        images = images.to(model.device)
        labels = labels.to(model.device)
        results = tta_adapter.adapt_batch(images, labels, return_predictions=True)
        break
    return tta_adapter
def example_5_custom_corruption():

    clean_image = torch.randn(3, 32, 32)
    noise = torch.randn_like(clean_image) * 0.5
    corrupted_image = torch.clamp(clean_image + noise, -1, 1)
    def tensor_to_pil(tensor):
        tensor = (tensor + 1) / 2
        tensor = tensor.clamp(0, 1)
        tensor = tensor.permute(1, 2, 0).numpy()
        tensor = (tensor * 255).astype(np.uint8)
        return Image.fromarray(tensor)
    clean_pil = tensor_to_pil(clean_image)
    corrupted_pil = tensor_to_pil(corrupted_image)
    return clean_pil, corrupted_pil
def example_6_batch_processing(model):
    from configs.config import CORRUPTIONS
    selected_corruptions = CORRUPTIONS[:3]
    results = {}
    for corruption in selected_corruptions:

        try:
            dataloader = get_corruption_dataloader(
                dataset_name='cifar10',
                corruption_type=corruption,
                severity=5,
                batch_size=64,
                data_root = "<DATA_ROOT_PATH>"
            )
            model.eval()
            correct = 0
            total = 0
            with torch.no_grad():
                for images, labels in dataloader:
                    images = images.to(model.device)
                    class_names = ['airplane', 'automobile', 'bird', 'cat', 'deer', 
                                 'dog', 'frog', 'horse', 'ship', 'truck']
                    text_prompts = [f"a photo of a {name}." for name in class_names]
                    text_inputs = model.processor(
                        text=text_prompts,
                        padding="max_length",
                        max_length=64,
                        return_tensors="pt"
                    ).to(model.device)
                    outputs = model(
                        pixel_values=images,
                        input_ids=text_inputs.input_ids,
                        attention_mask=text_inputs.attention_mask
                    )
                    logits = outputs['logits_per_image']
                    predictions = torch.argmax(logits, dim=-1)
                    correct += (predictions.cpu() == labels).sum().item()
                    total += labels.size(0)
                    break
            accuracy = correct / total
            results[corruption] = accuracy
        except Exception as e:
            continue
    for corruption, accuracy in results.items():
        pass

    return results
def main():

    if torch.cuda.is_available():
        pass
    else:
        pass

    model = example_1_load_model()
    dataloader = example_2_load_dataset()
    accuracy = example_3_zero_shot_inference(model, dataloader)
    tta_adapter = example_4_tta_adaptation(model, dataloader)
    clean_img, corrupted_img = example_5_custom_corruption()
    results = example_6_batch_processing(model)
if __name__ == '__main__':
    main()