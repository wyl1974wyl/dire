import os
os.environ["TOKENIZERS_PARALLELISM"] = "false"
import sys
import json
import torch
import argparse
import numpy as np
from tqdm import tqdm
from datetime import datetime
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
from models.dire_model import DIREModel, SimpleSIGLIP2Model
from datasets.corruption_datasets_fixed import (
    get_corruption_dataloader_fixed as get_corruption_dataloader,
    get_class_names
)
from tta.tta_adapters import OnlineTTAAdapter, AblationTTAAdapter
from configs.config import (
    DATASET_CONFIG, 
    CORRUPTIONS, 
    SEVERITY_LEVELS,
    MODEL_CONFIG,
    ABLATION_CONFIG,
    RESULTS_DIR
)
class ExperimentRunner:
    def __init__(self, 
                 dataset_name,
                 model_type='siglip2',
                 use_tta=False,
                 dit_ckpt_path=None,
                 results_dir=RESULTS_DIR,
                 confidence_threshold=None,
                 entropy_weight=None,
                 distance_compensated_weight=None):
        self.dataset_name = dataset_name
        self.model_type = model_type
        self.use_tta = use_tta
        self.dit_ckpt_path = dit_ckpt_path
        self.results_dir = results_dir
        self.overrides = {
            'confidence_threshold': confidence_threshold,
            'entropy_weight': entropy_weight,
            'distance_compensated_weight': distance_compensated_weight
        }
        os.makedirs(results_dir, exist_ok=True)
        self.dataset_config = DATASET_CONFIG[dataset_name]
        self.class_names = self._get_class_names()
        expected_num_classes = self.dataset_config['num_classes']
        actual_num_classes = len(self.class_names)
        if actual_num_classes != expected_num_classes:
            raise ValueError(f"Class count mismatch: expected {expected_num_classes}, got {actual_num_classes}")
        self._init_model()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model.to(self.device)
        if use_tta:

            self.tta_adapter = OnlineTTAAdapter(
                model=self.model,
                processor=self.processor,
                class_names=self.class_names,
                confidence_threshold=self._get_override('confidence_threshold', MODEL_CONFIG['confidence_threshold']),
                learning_rate=MODEL_CONFIG['tta_learning_rate'],
                entropy_weight=self._get_override('entropy_weight', 1.0),
                distance_weight=self._get_override('distance_compensated_weight', 1.0),
                use_dire=(self.model_type == 'dire')
            )
    def _get_override(self, key, default):

        return self.overrides.get(key) if self.overrides.get(key) is not None else default
    def _get_class_names(self):

        names = get_class_names(self.dataset_name)
        return names
    def _init_model(self):

        model_name = MODEL_CONFIG['siglip2_model_name']
        if self.model_type == 'siglip2':
            self.model = SimpleSIGLIP2Model(model_name=model_name)
        elif self.model_type == 'dire':
            self.model = DIREModel(
                siglip2_model_name=model_name,
                dit_ckpt_path=self.dit_ckpt_path
            )
        else:
            raise ValueError(f"Unknown model type: {self.model_type}")
        self.processor = self.model.processor
    def run_corruption_experiment(self, corruption, severity=5):

        try:
            dataloader = get_corruption_dataloader(
                dataset_name=self.dataset_name,
                corruption_type=corruption,
                severity=severity,
                batch_size=self.dataset_config['batch_size'],
                data_root = "<DATA_ROOT_PATH>",
                num_workers=0
            )
            results = {
                'dataset': self.dataset_name,
                'model': self.model_type,
                'tta': self.use_tta,
                'corruption': corruption,
                'severity': severity,
                'num_samples': len(dataloader.dataset),
                'hyperparameters': self.overrides
            }
            if self.use_tta:
                self.tta_adapter.reset_parameters()
                avg_losses = self.tta_adapter.adapt_dataloader(dataloader, desc=f"TTA {corruption}")
                eval_results = self.tta_adapter.evaluate_dataloader(dataloader, desc=f"Eval {corruption}")
                results.update({
                    'accuracy': eval_results['accuracy'],
                    'avg_losses': avg_losses
                })
            else:
                eval_results = self._zero_shot_evaluate(dataloader)
                results.update({'accuracy': eval_results['accuracy']})
            return results
        except Exception as e:
            import traceback
            traceback.print_exc()
            return {
                'dataset': self.dataset_name,
                'model': self.model_type,
                'tta': self.use_tta,
                'corruption': corruption,
                'severity': severity,
                'error': str(e),
                'accuracy': 0.0,
                'hyperparameters': self.overrides
            }
    def _zero_shot_evaluate(self, dataloader):
        """"""
        self.model.eval()
        all_predictions = []
        all_labels = []
        text_prompts = [f"a photo of a {name}." for name in self.class_names]
        with torch.no_grad():
            pbar = tqdm(dataloader, desc="Evaluating", leave=False)
            for batch_idx, (images, labels) in enumerate(pbar):
                try:
                    images = images.to(self.device)
                    labels = labels.to(self.device)
                    if batch_idx == 0:
                        pass

                    text_inputs = self.processor(
                        text=text_prompts,
                        padding="max_length",
                        max_length=64,
                        truncation=True,
                        return_tensors="pt"
                    )
                    text_inputs = {k: v.to(self.device) for k, v in text_inputs.items()}
                    if hasattr(self.model, 'get_vision_features'):

                        image_features = self.model.get_vision_features(images)
                        text_features = self.model.get_text_features(
                            text_inputs['input_ids'],
                            text_inputs.get('attention_mask')
                        )
                        image_features_norm = image_features / image_features.norm(dim=-1, keepdim=True)
                        text_features_norm = text_features / text_features.norm(dim=-1, keepdim=True)
                        logits = 10.0 * image_features_norm @ text_features_norm.t()
                    else:

                        outputs = self.model.model(
                            pixel_values=images,
                            input_ids=text_inputs['input_ids'],
                            attention_mask=text_inputs.get('attention_mask')
                        )
                        logits = outputs.logits_per_image
                    predictions = torch.argmax(logits, dim=-1)
                    all_predictions.append(predictions.cpu())
                    all_labels.append(labels.cpu())
                    if batch_idx % 10 == 0:
                        batch_acc = (predictions == labels).float().mean().item()
                        pbar.set_postfix({'Acc': f"{batch_acc:.3f}"})
                except Exception as e:
                    raise
        all_predictions = torch.cat(all_predictions)
        all_labels = torch.cat(all_labels)
        accuracy = (all_predictions == all_labels).float().mean().item()
        return {'accuracy': accuracy}
    def run_all_corruptions(self, severity=5):
        all_results = []
        for corruption in tqdm(CORRUPTIONS, desc="Corruptions"):
            result = self.run_corruption_experiment(corruption, severity)
            all_results.append(result)
        return all_results
    def save_results(self, results, suffix=""):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"{self.dataset_name}_{self.model_type}"
        if self.use_tta: filename += "_tta"
        if suffix: filename += f"_{suffix}"
        filename += f"_{timestamp}.json"
        filepath = os.path.join(self.results_dir, filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        return filepath
def main():
    parser = argparse.ArgumentParser(description='DIRE Experiment Runner with Hyperparameter Tuning')
    parser.add_argument('--dataset', type=str, required=True, 
                        choices=['imagenet', 'cifar10', 'cifar100'],
                        help='Dataset to use')
    parser.add_argument('--model', type=str, default='dire',
                        choices=['siglip2', 'dire'],
                        help='Model type')
    parser.add_argument('--tta', action='store_true',
                        help='Use TTA')
    parser.add_argument('--ablation', action='store_true',
                        help='Run ablation experiment')
    parser.add_argument('--corruption', type=str, default=None,
                        help='Specific corruption type (if None, run all)')
    parser.add_argument('--severity', type=int, default=5,
                        choices=[1, 2, 3, 4, 5],
                        help='Corruption severity level')
    parser.add_argument('--dit_ckpt', type=str, default='./ckpt/block0.pt',
                        help='Path to DIT checkpoint')
    parser.add_argument('--results_dir', type=str, default='./results',
                        help='Results directory')
    parser.add_argument('--confidence_threshold', type=float, default=None,
                        help='Override confidence threshold')
    parser.add_argument('--entropy_weight', type=float, default=None,
                        help='Override entropy weight')
    parser.add_argument('--distance_compensated_weight', type=float, default=None,
                        help='Override distance compensated weight')
    args = parser.parse_args()
    runner = ExperimentRunner(
        dataset_name=args.dataset,
        model_type=args.model,
        use_tta=args.tta,
        dit_ckpt_path=args.dit_ckpt,
        results_dir=args.results_dir,
        confidence_threshold=args.confidence_threshold,
        entropy_weight=args.entropy_weight,
        distance_compensated_weight=args.distance_compensated_weight
    )
    if args.corruption:
        result = runner.run_corruption_experiment(args.corruption, args.severity)
        runner.save_results([result])
    else:

        results = runner.run_all_corruptions(args.severity)
        suffix = f"conf{args.confidence_threshold}_ent{args.entropy_weight}_dist{args.distance_compensated_weight}"
        suffix = suffix.replace('.', 'p').replace('None', 'def')
        runner.save_results(results, suffix=suffix)
if __name__ == '__main__':
    main()