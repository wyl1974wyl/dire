import os
import torch
import numpy as np
from PIL import Image
import torchvision.transforms as transforms
from torch.utils.data import Dataset
import json
import ast
class CIFARCorruptionDataset(Dataset):
    def __init__(self, 
                 data_root,
                 dataset_name='cifar10',
                 corruption='gaussian_noise',
                 severity=5,
                 transform=None):
        self.data_root = data_root
        self.dataset_name = dataset_name
        self.corruption = corruption
        self.severity = severity
        self._load_corruption_data()
        self._load_labels()
        if transform is None:
            self.transform = transforms.Compose([
                transforms.ToPILImage(),
                transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ])
        else:
            self.transform = transform
    def _load_corruption_data(self):
        corruption_path = os.path.join(
            self.data_root, 
            f"{self.dataset_name}-C",
            f"{self.corruption}.npy"
        )
        if not os.path.exists(corruption_path):
            raise FileNotFoundError(f" Corruption file not found: {corruption_path}")
        raw_data = np.load(corruption_path)
        if len(raw_data.shape) == 4 and raw_data.shape[1] == 3:
            data = raw_data.transpose(0, 2, 3, 1)
        elif len(raw_data.shape) == 4 and raw_data.shape[3] == 3:
            data = raw_data
        else:
            raise ValueError(f" Unsupported data shape: {raw_data.shape}")
        images_per_severity = 10000
        start_idx = (self.severity - 1) * images_per_severity
        end_idx = self.severity * images_per_severity
        if end_idx > len(data):
            raise ValueError(f" Data size {len(data)} too small for severity {self.severity}")
        data = data[start_idx:end_idx]
        if data.dtype != np.uint8:
            data = (data * 255).astype(np.uint8) if data.max() <= 1.0 else data.astype(np.uint8)
        self.data = data
    def _load_labels(self):

        labels_path = os.path.join(self.data_root, f"{self.dataset_name}-C", "labels.npy")
        if not os.path.exists(labels_path):
            raise FileNotFoundError(f" Label file not found: {labels_path}")
        all_labels = np.load(labels_path)
        images_per_severity = 10000
        start_idx = (self.severity - 1) * images_per_severity
        end_idx = self.severity * images_per_severity
        self.labels = all_labels[start_idx:end_idx]
    def __len__(self):
        return len(self.data)
    def __getitem__(self, idx):
        image_array = self.data[idx]
        label = self.labels[idx]
        if self.transform:
            image = self.transform(image_array)
        else:
            image = torch.from_numpy(image_array).permute(2, 0, 1).float() / 255.0
        return image, label
class ImageNetCCorruptionDataset(Dataset):

    def __init__(self,
                 data_root,
                 corruption='gaussian_noise',
                 severity=5,
                 transform=None,
                 n_examples=-1):
        self.data_root = data_root
        self.corruption = corruption
        self.severity = severity
        self.transform = transform
        self.n_examples = n_examples
        self.class_to_idx = self._load_class_mapping()
        self.samples = self._load_samples()
    def _load_class_mapping(self):
        mapping_file = os.path.join(os.path.dirname(__file__), "imagenet_class_to_id_map.json")
        if not os.path.exists(mapping_file):
            raise FileNotFoundError(f" Mapping file not found: {mapping_file}")
        with open(mapping_file, 'r', encoding='utf-8') as f:
            class_to_idx = json.load(f)
        return class_to_idx
    def _load_samples(self):
        list_file = os.path.join(os.path.dirname(__file__), "imagenet_test_image_ids.txt")
        corruption_dir = os.path.join(self.data_root, "ImageNet-C", self.corruption, str(self.severity))
        if not os.path.exists(list_file):
            raise FileNotFoundError(f" Image list file not found: {list_file}")
        with open(list_file, 'r', encoding='utf-8') as f:
            fnames = [line.strip() for line in f if line.strip()]
        samples = []
        for fname in fnames:
            class_name = fname.split('/')[0]
            if class_name in self.class_to_idx:
                img_path = os.path.join(corruption_dir, fname)
                if os.path.exists(img_path):
                    samples.append((img_path, self.class_to_idx[class_name]))
        if len(samples) == 0:
            raise RuntimeError(f" No valid images found in {corruption_dir}")
        if self.n_examples > 0 and len(samples) > self.n_examples:
            np.random.shuffle(samples)
            samples = samples[:self.n_examples]
        return samples
    def __len__(self):
        return len(self.samples)
    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        image = Image.open(img_path).convert('RGB')
        if self.transform:
            image = self.transform(image)
        else:

            transform = transforms.Compose([
                transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ])
            image = transform(image)
        return image, label
def get_corruption_dataloader_fixed(dataset_name, 
                                   corruption_type, 
                                   severity=5,
                                   batch_size=64,
                                   num_workers=0,
                                   data_root="<DATA_ROOT_PATH>",
                                   transform=None,
                                   n_examples=-1):

    if dataset_name in ['cifar10', 'cifar100']:
        dataset = CIFARCorruptionDataset(
            data_root=data_root,
            dataset_name=dataset_name,
            corruption=corruption_type,
            severity=severity,
            transform=transform
        )
    elif dataset_name == 'imagenet':
        if transform is None:
            transform = get_imagenet_transform()
        dataset = ImageNetCCorruptionDataset(
            data_root=data_root,
            corruption=corruption_type,
            severity=severity,
            transform=transform,
            n_examples=n_examples
        )
    else:
        raise ValueError(f" Unknown dataset: {dataset_name}")
    return torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
def get_cifar_transform():

    return transforms.Compose([
        transforms.ToPILImage(),
        transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    ])
def get_imagenet_transform():

    return transforms.Compose([
        transforms.Resize((256, 256), interpolation=transforms.InterpolationMode.BICUBIC),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    ])
def load_imagenet_class_names():

    class_file = os.path.join(os.path.dirname(__file__), "imagenet_class.txt")
    if not os.path.exists(class_file):
        raise FileNotFoundError(f" Class names file not found: {class_file}")
    with open(class_file, 'r', encoding='utf-8') as f:
        content = f.read().strip()
    if content.startswith('[') and content.endswith(']'):
        try:
            class_names = ast.literal_eval(content)
            if isinstance(class_names, list) and len(class_names) > 1 and all(isinstance(name, str) for name in class_names):

                return class_names
        except (ValueError, SyntaxError, MemoryError) as e:
            pass

    with open(class_file, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    class_names = []
    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped and not stripped.startswith('#'):
            if (stripped.startswith("'") and stripped.endswith("'")) or \
               (stripped.startswith('"') and stripped.endswith('"')):
                stripped = stripped[1:-1]
            class_names.append(stripped)
    if len(class_names) != 1000:

        _create_diagnostic_file(class_names, class_file)
    return class_names
def _save_corrected_class_names(class_names, original_file):

    backup_file = original_file + '.bak'
    os.rename(original_file, backup_file)
    with open(original_file, 'w', encoding='utf-8') as f:
        for name in class_names:
            f.write(name + '\n')
def _create_diagnostic_file(class_names, original_file):

    diag_file = original_file + '.diagnostic.txt'
    with open(diag_file, 'w', encoding='utf-8') as f:
        f.write(f"File: {original_file}\n")
        f.write(f"Expected 1000 classes, found {len(class_names)}\n")
        f.write(f"Classes loaded:\n")
        for i, name in enumerate(class_names):
            f.write(f"{i}: {repr(name)}\n")
def get_class_names(dataset_name):

    if dataset_name == 'cifar10':
        return ['airplane', 'automobile', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']
    elif dataset_name == 'cifar100':
        return [
            'apple', 'aquarium_fish', 'baby', 'bear', 'beaver', 'bed', 'bee', 'beetle', 'bicycle', 'bottle',
            'bowl', 'boy', 'bridge', 'bus', 'butterfly', 'camel', 'can', 'castle', 'caterpillar', 'cattle',
            'chair', 'chimpanzee', 'clock', 'cloud', 'cockroach', 'couch', 'crab', 'crocodile', 'cup', 'dinosaur',
            'dolphin', 'elephant', 'flatfish', 'forest', 'fox', 'girl', 'hamster', 'house', 'kangaroo', 'computer_keyboard',
            'lamp', 'lawn_mower', 'leopard', 'lion', 'lizard', 'lobster', 'man', 'maple_tree', 'motorcycle', 'mountain',
            'mouse', 'mushroom', 'oak_tree', 'orange', 'orchid', 'otter', 'palm_tree', 'pear', 'pickup_truck', 'pine_tree',
            'plain', 'plate', 'poppy', 'porcupine', 'possum', 'rabbit', 'raccoon', 'ray', 'road', 'rocket',
            'rose', 'sea', 'seal', 'shark', 'shrew', 'skunk', 'skyscraper', 'snail', 'snake', 'spider',
            'squirrel', 'streetcar', 'sunflower', 'sweet_pepper', 'table', 'tank', 'telephone', 'television', 'tiger', 'tractor',
            'train', 'trout', 'tulip', 'turtle', 'wardrobe', 'whale', 'willow_tree', 'wolf', 'woman', 'worm'
        ]
    elif dataset_name == 'imagenet':
        return load_imagenet_class_names()
    else:
        raise ValueError(f" Unknown dataset: {dataset_name}")
if __name__ == '__main__':

    for ds_name in ['cifar10', 'cifar100', 'imagenet']:
        names = get_class_names(ds_name)
        if ds_name == 'imagenet':
            pass