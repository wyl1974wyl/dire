import os
DATA_ROOT = "<DATA_ROOT_PATH>"  # FIXME: Set your data root path
CKPT_PATH = "./ckpt/block0.pt"
RESULTS_DIR = "./results"
CACHE_DIR = "./cache"
MODEL_CONFIG = {
    "siglip2_model_name": "google/siglip2-base-patch16-256",  
    "dit_blocks": 1,  
    "confidence_threshold": 0.8,  
    "loss_weight": 0.5,  
    "learning_rate": 5e-4,  
    "tta_learning_rate": 5e-4,  
}
DATASET_CONFIG = {
    "imagenet": {
        "path": os.path.join(DATA_ROOT, "ImageNet-C"),
        "num_classes": 1000,
        "image_size": 256,  
        "batch_size": 64,
        "prompt_template": "a photo of a {}.",
    },
    "cifar10": {
        "path": os.path.join(DATA_ROOT, "CIFAR-10-C"),
        "num_classes": 10,
        "image_size": 256,   
        "batch_size": 200,
        "prompt_template": "a photo of a {}.",
    },
    "cifar100": {
        "path": os.path.join(DATA_ROOT, "CIFAR-100-C"),
        "num_classes": 100,
        "image_size": 256,   
        "batch_size": 200,
        "prompt_template": "a photo of a {}.",
    }
}
CORRUPTIONS = [
    "gaussian_noise", "shot_noise", "impulse_noise", "defocus_blur",
    "glass_blur", "motion_blur", "zoom_blur", "snow", "frost", "fog",
    "brightness", "contrast", "elastic_transform", "pixelate", "jpeg_compression"
]
SEVERITY_LEVELS = [1, 2, 3, 4, 5] 
TTA_CONFIG = {
    "entropy_weight": 2.0, 
    "projection_weight": 1.0,
    "separability_weight": 1.0,
    "distance_compensated_weight": 0.05, 
    "optimizer": "AdamW",
    "steps": 1, 
}
ABLATION_CONFIG = {
    "entropy_only": {"use_entropy": True, "use_projection": False, "use_separability": False, "use_distance": False},
    "projection_only": {"use_entropy": False, "use_projection": True, "use_separability": False, "use_distance": False},
    "separability_only": {"use_entropy": False, "use_projection": False, "use_separability": True, "use_distance": False},
    "distance_only": {"use_entropy": False, "use_projection": False, "use_separability": False, "use_distance": True},
    "entropy_projection": {"use_entropy": True, "use_projection": True, "use_separability": False, "use_distance": False},
    "full": {"use_entropy": True, "use_projection": True, "use_separability": True, "use_distance": True},
}
DEVICE_CONFIG = {
    "device": "cuda",
    "mixed_precision": True,
    "compile_model": False, 
}
LOGGING_CONFIG = {
    "log_interval": 10,
    "save_predictions": True,
    "results_file": "results.json",
}