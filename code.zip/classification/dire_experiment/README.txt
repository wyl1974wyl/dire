# Core deep learning
torch==1.11.0
torchvision==0.12.0

# HuggingFace ecosystem
transformers>=4.38.0
accelerate>=0.25.0
huggingface-hub>=0.20.0

# Scientific computing
numpy==1.22.3
scipy==1.8.1
pandas==1.4.2

# Image processing
Pillow==9.0.1
opencv-python==4.6.0.66
scikit-image==0.20.0
imageio==2.27.0
tifffile==2023.4.12
PyWavelets==1.4.1

# Visualization
matplotlib==3.5.2
seaborn==0.12.0

# Machine learning utilities
scikit-learn==1.2.2
joblib==1.2.0
threadpoolctl==3.1.0

# Progress and logging
tqdm==4.64.0
termcolor==2.3.0
tensorboard==2.13.0
tensorboardx==2.6
tensorboard-data-server==0.7.1

# Configuration and serialization
pyyaml==6.0
addict==2.4.0
simplejson==3.19.1

# Computer vision / detection utilities
mmcv==1.5.3
mmcv-full==1.5.3
openmim==0.2.0
iopath==0.1.10
fvcore==0.1.5.post20221221
portalocker==2.7.0
pycocotools==2.0.4
pybboxes==0.1.6
sahi==0.11.14
shapely==2.0.1

# Model utilities
timm==0.5.4
einops==0.6.1
thop==0.1.0-2206102148
segment-anything==1.0

# Network and data handling
requests==2.27.1
requests-oauthlib==1.3.1
urllib3==1.26.9

# Google auth (for tensorboard / cloud)
google-auth==2.21.0
google-auth-oauthlib==1.0.0
oauthlib==3.2.2
pyasn1==0.5.0
pyasn1-modules==0.3.0
rsa==4.9

# Protobuf
protobuf==3.20.1

# Markdown / rich text
markdown==3.3.7
rich==12.4.4
commonmark==0.9.1
pygments==2.12.0

# Web / server
werkzeug==2.3.6
grpcio==1.56.0

# Other utilities
click==8.1.3
colorama==0.4.5
cycler==0.11.0
dill==0.3.5.1
dominate==2.6.0
fire==0.5.0
fonttools==4.33.3
kiwisolver==1.4.3
lazy-loader==0.2
model-index==0.1.11
networkx==3.1
onnx==1.12.0
ordered-set==4.1.0
packaging==21.3
python-dateutil==2.8.2
pytz==2022.1
simplification==0.6.11
tabulate==0.8.10
terminaltables==3.1.10
yacs==0.1.8
yapf==0.32.0

# Cryptography / SSL
cryptography==37.0.1
pyopenssl==22.0.0
cffi==1.15.0
pycparser==2.21
certifi==2022.5.18.1

# IDNA / charset
idna==3.3
charset-normalizer==2.0.4

# SOCKS / proxy
pysocks==1.7.1

# Six
six==1.16.0

# absl
absl-py==1.4.0

# Cache tools
cachetools==5.3.1
