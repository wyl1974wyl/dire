#!/usr/bin/env python

import os
import sys
import logging
import torch
from PIL import Image
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def test_siglip_source_path():

    logger.info("="*60)
    logger.info(" SIGLIP_SOURCE")
    logger.info("="*60)
    
    from conf import cfg, merge_from_file
    merge_from_file("cfgs/imagenet_c/siglip_baseline.yaml")

    cfg.MODEL.USE_SIGLIP = True
    cfg.MODEL.USE_DIRE = False
    cfg.MODEL.USE_CLIP = False
    cfg.MODEL.ADAPTATION = "siglipsource"
    cfg.MODEL.ARCH = "siglip2-base-patch16-256"

    from models.model import get_model
    model, preprocess = get_model(cfg, num_classes=1000, device="cpu")
    
    if hasattr(model, "text_features"):
        logger.info(f"text_features: {model.text_features.shape}")
        
        similarity = model.text_features @ model.text_features.T
        eye = torch.eye(len(model.text_features))
        inter_class_sim = (similarity * (1 - eye)).mean().item()
        
        logger.info(f": {inter_class_sim:.4f} (ok<0.3)")

        from datasets.cls_names import imagenet_classes
        test_indices = [0, 9, 99, 372]  # tench, ostrich, goose, baboon

        for i in test_indices:
            for j in test_indices:
                if i < j:
                    sim = (model.text_features[i] @ model.text_features[j]).item()
                    logger.info(f"  {imagenet_classes[i]} vs {imagenet_classes[j]}: {sim:.4f}")

        feature_variance = model.text_features.var(dim=0).mean().item()
        logger.info(f"\n: {feature_variance:.6f} (ok >0.001)")
        
        is_healthy = inter_class_sim < 0.3 and feature_variance > 0.001
        
        
        return is_healthy
    else:
        logger.error("❌ text_features")
        return False

def test_real_prediction():
    logger.info(f"\n{'='*60}")
    logger.info(f"{'='*60}")
    
    from conf import cfg, merge_from_file
    merge_from_file("cfgs/imagenet_c/siglip_baseline.yaml")
    cfg.MODEL.USE_SIGLIP = True
    cfg.MODEL.ADAPTATION = "siglipsource"
    
    from models.model import get_model
    model, _ = get_model(cfg, num_classes=1000, device="cpu")

    from datasets.data_loading import get_test_loader
    data_loader = get_test_loader(
        setting="reset_each_shift",
        adaptation="siglipsource",
        dataset_name="imagenet_c",
        preprocess=None,
        data_root_dir="/data/wlb",
        domain_name="gaussian_noise",
        domain_names_all=["gaussian_noise"],
        severity=5,
        num_examples=10,
        rng_seed=1,
        use_clip=False,
        use_siglip=True,
        batch_size=1
    )
    
    first_sample = data_loader.dataset.samples[0]
    img_path, true_label = first_sample
    
    from datasets.cls_names import imagenet_classes
    logger.info(f": {imagenet_classes[true_label]}")

    pil_img = Image.open(img_path).convert('RGB')
    with torch.no_grad():
        logits = model([pil_img])
        probs = torch.softmax(logits, dim=-1)
        pred = logits.argmax(dim=1).item()
        
        logger.info(f": {imagenet_classes[pred]}")
        logger.info(f": {probs[0, pred].item():.4f}")
        logger.info(f"Top-5: {torch.topk(probs[0], 5)}")
        
        return pred == true_label

def main():
    
    path_ok = test_siglip_source_path()    
    if path_ok:
        logger.info("🎉 SIGLIP_SOURCE！")
        logger.info("   python run_dire.py --cfg cfgs/imagenet_c/siglip_baseline.yaml")
        return 0
    else:
        logger.error("❌ SIGLIP_SOURCE！")
        return 1

if __name__ == "__main__":
    sys.exit(main())