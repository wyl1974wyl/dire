#!/usr/bin/env python

import os
import sys
import logging
import torch
import traceback
import argparse
from datetime import datetime

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from conf import cfg, merge_from_file
from test_time import evaluate
from utils.misc import setup_logging

logger = logging.getLogger(__name__)


def parse_args():
    """Parse command line arguments"""
    parser = argparse.ArgumentParser(description="DIRE: Diffusion-Informed Representation Enhancement")
    parser.add_argument("--cfg", type=str, required=True, help="Config file path")
    parser.add_argument("--dit-path", type=str, help="Path to DiT pretrained checkpoint")
    parser.add_argument("--dataset", type=str, choices=["imagenet_c", "cifar10_c", "cifar100_c"], 
                       help="Override dataset")
    parser.add_argument("--corruption", type=str, help="Specific corruption type")
    parser.add_argument("--severity", type=int, choices=[1, 2, 3, 4, 5], help="Corruption severity")
    parser.add_argument("--batch-size", type=int, help="Override batch size")
    parser.add_argument("--lr", type=float, help="Override learning rate")
    parser.add_argument("--gpu", type=int, default=0, help="GPU ID")
    parser.add_argument("--output-dir", type=str, help="Override output directory")
    parser.add_argument("opts", default=None, nargs=argparse.REMAINDER,
                       help="Additional config options")
    
    return parser.parse_args()


def setup_environment(args):
    """Setup environment variables and GPU"""
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    
    if "HF_ENDPOINT" not in os.environ:
        os.environ["HF_ENDPOINT"] = "https://huggingface.co"
    
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    setup_logging()


def load_and_configure_cfg(args):
    """Load config and apply command line overrides"""
    # Load base config from file
    merge_from_file(args.cfg)
    
    # Apply command line overrides
    if args.dit_path and getattr(cfg.MODEL, 'USE_DIRE', False):
        cfg.DIRE.DIT_PRETRAINED_PATH = args.dit_path
    if args.dataset:
        cfg.CORRUPTION.DATASET = args.dataset
    if args.corruption:
        cfg.CORRUPTION.TYPE = [args.corruption]
    if args.severity:
        cfg.CORRUPTION.SEVERITY = [args.severity]
    if args.batch_size:
        cfg.TEST.BATCH_SIZE = args.batch_size
    if args.lr:
        cfg.OPTIM.LR = args.lr
    if args.output_dir:
        cfg.SAVE_DIR = args.output_dir
    
    if args.opts:
        cfg.merge_from_list(args.opts)
    
    # Setup save directory
    timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
    if getattr(cfg.MODEL, 'USE_DIRE', False):
        cfg.SAVE_DIR = os.path.join(cfg.SAVE_DIR, f"{cfg.MODEL.ADAPTATION}_{cfg.CORRUPTION.DATASET}_{timestamp}")
    else:
        cfg.SAVE_DIR = os.path.join(cfg.SAVE_DIR, f"baseline_{cfg.MODEL.ADAPTATION}_{cfg.CORRUPTION.DATASET}_{timestamp}")
    
    os.makedirs(cfg.SAVE_DIR, exist_ok=True)
    
    # Setup logging
    import random
    import numpy as np
    
    log_dest = os.path.basename(args.cfg).replace('.yaml', f'_{timestamp}.txt')
    cfg.LOG_TIME, cfg.LOG_DEST = timestamp, log_dest
    
    logging.basicConfig(
        level=logging.INFO,
        format="[%(asctime)s] [%(filename)s: %(lineno)4d]: %(message)s",
        datefmt="%y/%m/%d %H:%M:%S",
        handlers=[
            logging.FileHandler(os.path.join(cfg.SAVE_DIR, cfg.LOG_DEST)),
            logging.StreamHandler()
        ]
    )
    
    if cfg.RNG_SEED:
        torch.manual_seed(cfg.RNG_SEED)
        torch.cuda.manual_seed(cfg.RNG_SEED)
        np.random.seed(cfg.RNG_SEED)
        random.seed(cfg.RNG_SEED)
        torch.backends.cudnn.benchmark = cfg.CUDNN.BENCHMARK
        
        if cfg.DETERMINISM:
            torch.backends.cudnn.deterministic = True


def validate_config(cfg):
    """Validate configuration"""
    if getattr(cfg.MODEL, 'USE_DIRE', False):
        if cfg.MODEL.ADAPTATION != "dire":
            raise ValueError("DIRE requires MODEL.ADAPTATION to be 'dire'")
        
        if not hasattr(cfg, 'DIRE') or not cfg.DIRE.DIT_PRETRAINED_PATH:
            raise ValueError("DIRE requires DIRE.DIT_PRETRAINED_PATH to be set")
        
        if not os.path.exists(cfg.DIRE.DIT_PRETRAINED_PATH):
            raise FileNotFoundError(f"DiT pretrained weights not found: {cfg.DIRE.DIT_PRETRAINED_PATH}")
        
        logger.info("✅ DIRE configuration validated")
    else:
        logger.info("⚠️  Running in baseline mode (non-DIRE)")


def print_model_info(cfg):
    """Print model information dynamically"""
    print("=" * 60)
    if getattr(cfg.MODEL, 'USE_DIRE', False):
        print("DIRE: Diffusion-Informed Representation Enhancement")
        print(f"Architecture: SigLIP2 + Shallow DiT blocks")
    elif getattr(cfg.MODEL, 'USE_SIGLIP', False):
        print("SigLIP2 Zero-Shot Model (HuggingFace)")
    elif getattr(cfg.MODEL, 'USE_CLIP', False):
        print("CLIP Zero-Shot Model")
    else:
        print("Standard Model")
    print(f"Paper: ICML 2026")
    print("=" * 60)
    print()


def main():
    """Main function"""
    args = parse_args()
    
    # Print banner
    print("=" * 60)
    print("DIRE Runner (Enhanced for Baseline Testing)")
    print("=" * 60)
    print(f"Configuration: {args.cfg}")
    print("=" * 60)
    print()
    
    # Setup environment
    setup_environment(args)
    
    # Load and configure
    print(f"Loading config from: {args.cfg}")
    load_and_configure_cfg(args)
    
    # Validate config
    validate_config(cfg)
    
    # Print model info
    print_model_info(cfg)
    
    # Print configuration
    print("\nConfiguration:")
    print(f"  Dataset: {cfg.CORRUPTION.DATASET}")
    print(f"  Corruptions: {cfg.CORRUPTION.TYPE}")
    print(f"  Severities: {cfg.CORRUPTION.SEVERITY}")
    print(f"  Batch size: {cfg.TEST.BATCH_SIZE}")
    print(f"  Learning rate: {cfg.OPTIM.LR}")

    if getattr(cfg.MODEL, 'USE_DIRE', False):
        print(f"  DiT blocks: {cfg.DIRE.NUM_DIT_BLOCKS}")
        print(f"  Confidence threshold: {cfg.DIRE.CONFIDENCE_THRESHOLD}")
    
    print(f"  Output dir: {cfg.SAVE_DIR}")
    print()
    
    # Run evaluation
    try:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"Using device: {device}")

        evaluate("DIRE Evaluation", external_cfg=cfg)
        
        # Print summary
        print("\n" + "=" * 60)
        print("EVALUATION COMPLETE")
        print("=" * 60)
        print(f"Results saved to: {cfg.SAVE_DIR}")
        
    except Exception as e:
        logger.error(f"Evaluation failed: {e}")
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()