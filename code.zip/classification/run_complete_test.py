#!/usr/bin/env python
"""
DIRE Complete Test Runner
Automated script to run all test scenarios for DIRE
"""

import os
import sys
import subprocess
import argparse
import logging
import json
from pathlib import Path
from datetime import datetime

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Color codes
GREEN = '\033[0;32m'
RED = '\033[0;31m'
YELLOW = '\033[1;33m'
BLUE = '\033[0;34m'
NC = '\033[0m'  # No Color


class DIRETester:
    def __init__(self, dit_path="./ckpt/block0.pt", gpu=0, output_base="./output"):
        self.dit_path = dit_path
        self.gpu = gpu
        self.output_base = output_base
        self.results = []
        
        # Create output directory
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.test_dir = Path(output_base) / f"complete_test_{self.timestamp}"
        self.test_dir.mkdir(parents=True, exist_ok=True)
        
        # Define test scenarios
        self.scenarios = {
            "imagenet_c": {
                "corruptions": [
                    "gaussian_noise", "shot_noise", "impulse_noise",
                    "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",
                    "snow", "frost", "fog", "brightness", "contrast",
                    "elastic_transform", "pixelate", "jpeg_compression"
                ],
                "cfg": "cfgs/imagenet_c/dire.yaml"
            },
            "cifar10_c": {
                "corruptions": [
                    "gaussian_noise", "shot_noise", "impulse_noise",
                    "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",
                    "snow", "frost", "fog", "brightness", "contrast",
                    "elastic_transform", "pixelate", "jpeg_compression"
                ],
                "cfg": "cfgs/cifar10_c/dire.yaml"
            },
            "cifar100_c": {
                "corruptions": [
                    "gaussian_noise", "shot_noise", "impulse_noise",
                    "defocus_blur", "glass_blur", "motion_blur", "zoom_blur",
                    "snow", "frost", "fog", "brightness", "contrast",
                    "elastic_transform", "pixelate", "jpeg_compression"
                ],
                "cfg": "cfgs/cifar100_c/dire.yaml"
            }
        }
        
        # Severity levels to test
        self.severities = [5]  # Focus on highest severity
        
    def run_command(self, cmd, check=True):
        """Run shell command and return result"""
        logger.info(f"Running: {cmd}")
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        if result.returncode != 0:
            logger.error(f"Command failed: {result.stderr}")
            if check:
                raise RuntimeError(f"Command failed: {cmd}")
        
        return result
    
    def test_single_scenario(self, dataset, corruption, severity):
        """Test a single scenario"""
        cfg_file = self.scenarios[dataset]["cfg"]
        output_dir = self.test_dir / dataset / f"{corruption}_severity{severity}"
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Build command - FIXED: Removed extra quotes
        cmd_parts = [
            "python run_dire.py",
            f"--cfg {cfg_file}",
            f"--dit-path {self.dit_path}",
            f"--corruption {corruption}",
            f"--severity {severity}",
            f"--gpu {self.gpu}",
            f"--output-dir {output_dir}"
        ]
        cmd = " ".join(cmd_parts)
        
        # Log file
        log_file = output_dir / "test.log"
        
        try:
            # Run command
            result = self.run_command(cmd, check=False)
            
            # Write log
            with open(log_file, 'w') as f:
                f.write(f"Command: {cmd}\n")
                f.write(f"Return code: {result.returncode}\n")
                f.write(f"STDOUT:\n{result.stdout}\n")
                f.write(f"STDERR:\n{result.stderr}\n")
            
            # Parse accuracy from output
            accuracy = None
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'error' in line.lower() and '%' in line:
                        try:
                            # Extract error percentage
                            err_str = line.split(':')[1].strip().replace('%', '')
                            error = float(err_str) / 100
                            accuracy = 1.0 - error
                            break
                        except:
                            pass
            
            # Store result
            test_result = {
                "dataset": dataset,
                "corruption": corruption,
                "severity": severity,
                "accuracy": accuracy,
                "success": result.returncode == 0,
                "output_dir": str(output_dir),
                "return_code": result.returncode
            }
            
            self.results.append(test_result)
            
            # Print status
            if result.returncode == 0 and accuracy is not None:
                print(f"{GREEN}✅ {dataset} - {corruption} (severity {severity}): {accuracy:.2%}{NC}")
            elif result.returncode == 0:
                print(f"{YELLOW}⚠️  {dataset} - {corruption} (severity {severity}): Completed but no accuracy{NC}")
            else:
                print(f"{RED}❌ {dataset} - {corruption} (severity {severity}): Failed{NC}")
            
            return result.returncode == 0
            
        except Exception as e:
            logger.error(f"Exception during test: {e}")
            return False
    
    def run_ablation_study(self):
        """Run ablation studies"""
        print(f"\n{BLUE}========================================{NC}")
        print(f"{BLUE} Running Ablation Studies{NC}")
        print(f"{BLUE}========================================{NC}\n")
        
        ablations = [
            {
                "name": "num_dit_blocks",
                "description": "Testing different numbers of DiT blocks",
                "configs": [
                    ("DIRE.NUM_DIT_BLOCKS=2", "blocks_2"),
                    ("DIRE.NUM_DIT_BLOCKS=3", "blocks_3"),
                    ("DIRE.NUM_DIT_BLOCKS=4", "blocks_4"),
                    ("DIRE.NUM_DIT_BLOCKS=5", "blocks_5"),
                    ("DIRE.NUM_DIT_BLOCKS=6", "blocks_6"),
                ]
            },
            {
                "name": "confidence_threshold",
                "description": "Testing different confidence thresholds",
                "configs": [
                    ("DIRE.CONFIDENCE_THRESHOLD=0.7", "conf_0.7"),
                    ("DIRE.CONFIDENCE_THRESHOLD=0.8", "conf_0.8"),
                    ("DIRE.CONFIDENCE_THRESHOLD=0.85", "conf_0.85"),
                    ("DIRE.CONFIDENCE_THRESHOLD=0.9", "conf_0.9"),
                ]
            },
            {
                "name": "learning_rate",
                "description": "Testing different learning rates",
                "configs": [
                    ("OPTIM.LR=1e-4", "lr_1e-4"),
                    ("OPTIM.LR=5e-4", "lr_5e-4"),
                    ("OPTIM.LR=1e-3", "lr_1e-3"),
                    ("OPTIM.LR=5e-3", "lr_5e-3"),
                ]
            }
        ]
        
        for ablation in ablations:
            print(f"\n{YELLOW}{ablation['description']}{NC}\n")
            
            for config, suffix in ablation["configs"]:
                output_dir = self.test_dir / "ablation" / ablation["name"] / suffix
                output_dir.mkdir(parents=True, exist_ok=True)
                
                # Build command - FIXED: Removed extra quotes
                cmd_parts = [
                    "python run_dire.py",
                    "--cfg cfgs/imagenet_c/dire.yaml",
                    f"--dit-path {self.dit_path}",
                    "--corruption gaussian_noise",
                    "--severity 5",
                    f"--gpu {self.gpu}",
                    f"--output-dir {output_dir}",
                    f"--opts {config}"
                ]
                cmd = " ".join(cmd_parts)
                
                try:
                    result = self.run_command(cmd, check=False)
                    
                    if result.returncode == 0:
                        print(f"{GREEN}✅ {suffix}: Success{NC}")
                    else:
                        print(f"{RED}❌ {suffix}: Failed{NC}")
                        
                except Exception as e:
                    print(f"{RED}❌ {suffix}: Exception - {e}{NC}")
    
    def generate_report(self):
        """Generate test report"""
        print(f"\n{BLUE}========================================{NC}")
        print(f"{BLUE} Generating Test Report{NC}")
        print(f"{BLUE}========================================{NC}\n")
        
        # Calculate statistics
        total_tests = len(self.results)
        successful_tests = sum(1 for r in self.results if r["success"])
        tests_with_accuracy = sum(1 for r in self.results if r["accuracy"] is not None)
        
        print(f"Total tests: {total_tests}")
        print(f"Successful: {successful_tests}")
        print(f"Failed: {total_tests - successful_tests}")
        print(f"With accuracy: {tests_with_accuracy}")
        
        if tests_with_accuracy > 0:
            accuracies = [r["accuracy"] for r in self.results if r["accuracy"] is not None]
            print(f"\nAccuracy Statistics:")
            print(f"  Mean: {sum(accuracies)/len(accuracies):.2%}")
            print(f"  Min: {min(accuracies):.2%}")
            print(f"  Max: {max(accuracies):.2%}")
        
        # Save detailed results
        results_file = self.test_dir / "results.json"
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        print(f"\nDetailed results saved to: {results_file}")
        
        # Generate CSV report
        if tests_with_accuracy > 0:
            csv_file = self.test_dir / "results.csv"
            with open(csv_file, 'w') as f:
                f.write("dataset,corruption,severity,accuracy,success\n")
                for r in self.results:
                    if r["accuracy"] is not None:
                        f.write(f"{r['dataset']},{r['corruption']},{r['severity']},{r['accuracy']},{r['success']}\n")
            
            print(f"CSV report saved to: {csv_file}")
    
    def run_complete_test(self, datasets=None, run_ablation=False):
        """Run complete test suite"""
        print(f"{GREEN}========================================{NC}")
        print(f"{GREEN} DIRE Complete Test Suite{NC}")
        print(f"{GREEN}========================================{NC}\n")
        
        print(f"Test directory: {self.test_dir}")
        print(f"DiT weights: {self.dit_path}")
        print(f"GPU: {self.gpu}")
        print()
        
        # Check if DIT weights exist
        if not os.path.exists(self.dit_path):
            print(f"{RED}Error: DiT weights not found at {self.dit_path}{NC}")
            print(f"Please download using: python download_dit.py --source hf --output-dir ./ckpt")
            return False
        
        # Use specified datasets or all
        if datasets is None:
            datasets = list(self.scenarios.keys())
        
        total_tests = sum(len(self.scenarios[d]["corruptions"]) * len(self.severities) 
                         for d in datasets)
        current_test = 0
        
        # Run main tests
        for dataset in datasets:
            print(f"\n{BLUE}Testing {dataset}...{NC}\n")
            
            for corruption in self.scenarios[dataset]["corruptions"]:
                for severity in self.severities:
                    current_test += 1
                    print(f"[{current_test}/{total_tests}] ", end="")
                    
                    self.test_single_scenario(dataset, corruption, severity)
        
        # Run ablation studies if requested
        if run_ablation:
            self.run_ablation_study()
        
        # Generate report
        self.generate_report()
        
        print(f"\n{GREEN}========================================{NC}")
        print(f"{GREEN} Complete test finished!{NC}")
        print(f"{GREEN}========================================{NC}\n")
        
        return True


def main():
    parser = argparse.ArgumentParser(description="DIRE Complete Test Runner")
    parser.add_argument("--dit-path", type=str, default="./ckpt/block0.pt",
                       help="Path to DiT pretrained weights")
    parser.add_argument("--gpu", type=int, default=0,
                       help="GPU ID to use")
    parser.add_argument("--output-dir", type=str, default="./output",
                       help="Output directory")
    parser.add_argument("--datasets", nargs="+", 
                       choices=["imagenet_c", "cifar10_c", "cifar100_c"],
                       help="Datasets to test (default: all)")
    parser.add_argument("--ablation", action="store_true",
                       help="Run ablation studies")
    parser.add_argument("--quick", action="store_true",
                       help="Quick test (single dataset, single corruption)")
    
    args = parser.parse_args()
    
    # Create tester
    tester = DIRETester(
        dit_path=args.dit_path,
        gpu=args.gpu,
        output_base=args.output_dir
    )
    
    # Run tests
    if args.quick:
        # Quick test
        print(f"\n{YELLOW}Running quick test...{NC}\n")
        tester.test_single_scenario("cifar10_c", "gaussian_noise", 5)
        tester.generate_report()
    else:
        # Complete test
        tester.run_complete_test(
            datasets=args.datasets,
            run_ablation=args.ablation
        )


if __name__ == "__main__":
    main()
