#!/usr/bin/env python3
"""
Extract First DiT Block (No EMA, Compact Size)
Usage: python extract_block0.py /path/to/0005000.pt /path/to/block0.pt
"""

import torch
import sys
from pathlib import Path

def extract_block0(input_path: str, output_path: str):
    """Extract first DiT block parameters, ensuring 768D input/output and minimal file size."""
    
    # 1. Load checkpoint
    ckpt = torch.load(input_path, map_location='cpu')
    state_dict = ckpt.get('model', ckpt)
    
    # 2. Extract blocks.0 parameters (strictly detached)
    block0_params = {}
    for key, param in state_dict.items():
        if key.startswith('blocks.0.'):
            # Detach and ensure no grad information
            block0_params[key] = param.detach().cpu().clone().requires_grad_(False)
    
    if not block0_params:
        print("❌ No blocks.0 parameters found")
        sys.exit(1)
    
    # 3. Verify dimensions
    input_dim = block0_params['blocks.0.norm1.weight'].shape[0]
    output_dim = block0_params['blocks.0.attn.proj.weight'].shape[0]
    
    if input_dim != 768 or output_dim != 768:
        print(f"⚠️  Dimension mismatch: in={input_dim}, out={output_dim}")
    
    # 4. Build minimal checkpoint (NO EMA, NO metadata)
    output_ckpt = {'model': block0_params}
    
    # 5. Save with compression
    try:
        torch.save(output_ckpt, output_path, _use_new_zipfile_serialization=True)
        
        # Verify size
        actual_mb = Path(output_path).stat().st_size / 1024**2
        param_count = sum(p.numel() for p in block0_params.values())
        expected_mb = param_count * 4 / 1024**2  # float32
        
        print(f"\n✅ Extraction successful: {output_path}")
        print(f"📊 Parameters: {param_count:,}")
        print(f"📊 Dimensions: {input_dim}D → {output_dim}D")
        print(f"📊 Expected size: ~{expected_mb:.1f} MB")
        print(f"📊 Actual size: {actual_mb:.1f} MB")
        
        if actual_mb > expected_mb * 1.2:
            print("⚠️  Warning: File size larger than expected")
            
    except Exception as e:
        print(f"❌ Save failed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python extract_block0.py <input.pt> <output.pt>")
        sys.exit(1)
    
    input_pt, output_pt = Path(sys.argv[1]), Path(sys.argv[2])
    
    if not input_pt.exists():
        print(f"❌ File not found: {input_pt}")
        sys.exit(1)
    
    if input_pt == output_pt:
        print("❌ Input and output must be different")
        sys.exit(1)
    
    extract_block0(str(input_pt), str(output_pt))